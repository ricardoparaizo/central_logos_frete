import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { LogoGenerator } from "./components/LogoGenerator";
import { ImageConverter } from "./components/ImageConverter";
import { Help } from "./components/Help";
import FretebrasStyleHeader from "./components/FretebrasStyleHeader";
import gallerySvgPaths from "./imports/svg-7u1rrwg8vo";

function ImageGalleryIcon() {
  return (
    <div className="relative size-5">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 48 48"
      >
        <g>
          <path
            clipRule="evenodd"
            d={gallerySvgPaths.ped2b2f0}
            fill="white"
            fillRule="evenodd"
          />
          <path 
            d={gallerySvgPaths.p1abb1700} 
            fill="white" 
          />
        </g>
      </svg>
    </div>
  );
}

function IconButton() {
  return (
    <div
      className="relative rounded-full size-12"
      style={{
        backgroundImage:
          "linear-gradient(47.3859deg, rgb(7, 105, 218) 13.831%, rgb(206, 220, 255) 88.961%)",
      }}
    >
      <div className="flex flex-row items-center justify-center p-0 relative size-12">
        <ImageGalleryIcon />
      </div>
    </div>
  );
}

type PageType = "home" | "help";
type TabType = "generator" | "converter";

interface TabButtonProps {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}

function TabButton({
  active,
  onClick,
  children
}: TabButtonProps) {
  const baseClasses = "relative rounded-full px-6 py-3 cursor-pointer transition-all duration-200";
  
  return (
    <div
      className={`${baseClasses} ${
        active
          ? "bg-[#0769da] text-white"
          : "bg-[rgba(0,43,92,0.06)] text-[#111111] hover:bg-[rgba(0,43,92,0.1)]"
      }`}
      onClick={onClick}
    >
      <div className="flex flex-row items-center justify-center">
        <span className="font-medium text-[14px] text-center whitespace-nowrap">
          {children}
        </span>
      </div>
    </div>
  );
}

function Divider() {
  return (
    <div className="relative w-full">
      <div className="flex flex-col items-start justify-start p-0 relative w-full">
        <div className="bg-[#dfe1e6] h-px w-full" />
      </div>
    </div>
  );
}

// Page transition variants
const pageVariants = {
  initial: {
    opacity: 0,
    x: 20,
    scale: 0.98
  },
  in: {
    opacity: 1,
    x: 0,
    scale: 1
  },
  out: {
    opacity: 0,
    x: -20,
    scale: 0.98
  }
};

const pageTransition = {
  type: "tween",
  ease: [0.4, 0, 0.2, 1],
  duration: 0.4
};

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageType>("home");
  const [activeTab, setActiveTab] = useState<TabType>("generator");

  // Function to handle navigation
  const handleNavigation = (page: PageType) => {
    setCurrentPage(page);
  };

  return (
    <div className="bg-white relative min-h-screen">
      <div className="flex flex-col relative w-full">
        {/* Fretebras Style Header with current page state */}
        <FretebrasStyleHeader 
          onNavigate={handleNavigation} 
          currentPage={currentPage}
        />

        {/* Main Content */}
        <main className="flex-1">
          <div className="flex items-center justify-center relative w-full">
            {/* Animated content based on current page */}
            <AnimatePresence mode="wait">
              {currentPage === "help" ? (
                <motion.div
                  key="help"
                  initial="initial"
                  animate="in"
                  exit="out"
                  variants={pageVariants}
                  transition={pageTransition}
                  className="relative w-full max-w-4xl mx-auto"
                >
                  <div className="flex flex-col items-center justify-center relative w-full">
                    <div className="flex flex-col gap-10 items-center justify-center px-6 py-20 relative w-full max-w-[660px]">
                      <Help />
                    </div>
                  </div>
                </motion.div>
              ) : (
                /* Central de Logos Content - Home Page */
                <motion.div
                  key="home"
                  initial="initial"
                  animate="in"
                  exit="out"
                  variants={pageVariants}
                  transition={pageTransition}
                  className="relative w-full max-w-4xl mx-auto"
                >
                  <div className="flex flex-col items-center justify-center relative w-full">
                    <div className="flex flex-col gap-10 items-center justify-center px-6 py-20 relative w-full max-w-[660px]">
                      {/* Title Section */}
                      <motion.div 
                        className="relative"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.1, duration: 0.5 }}
                      >
                        <div className="flex flex-col gap-3 items-center justify-start p-0 relative">
                          <IconButton />
                          <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center text-nowrap">
                            <h1 className="adjustLetterSpacing block leading-[1.1] whitespace-pre font-bold text-[40px] tracking-[-1.6px] text-[rgba(17,17,17,1)]">
                              Central de Logos
                            </h1>
                          </div>
                        </div>
                      </motion.div>

                      {/* Navigation Tabs */}
                      <motion.div 
                        className="relative"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2, duration: 0.5 }}
                      >
                        <div className="flex flex-col gap-4 items-center justify-start p-0 relative">
                          <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center text-nowrap">
                            <p className="block leading-[1.5] whitespace-pre font-medium text-[16px]">
                              Escolha o serviço que você precisa para o seu logo.
                            </p>
                          </div>

                          <div className="flex flex-row gap-3 items-center justify-center p-0 relative flex-wrap">
                            <TabButton
                              active={activeTab === "generator"}
                              onClick={() => setActiveTab("generator")}
                            >
                              Criar logo
                            </TabButton>
                            <TabButton
                              active={activeTab === "converter"}
                              onClick={() => setActiveTab("converter")}
                            >
                              Padronizar logo
                            </TabButton>
                          </div>
                        </div>
                      </motion.div>

                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.3, duration: 0.5 }}
                      >
                        <Divider />
                      </motion.div>

                      {/* Content based on active tab */}
                      <motion.div 
                        className="w-full"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.4, duration: 0.5 }}
                      >
                        <AnimatePresence mode="wait">
                          {activeTab === "generator" ? (
                            <motion.div
                              key="generator"
                              initial={{ opacity: 0, x: 20 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -20 }}
                              transition={{ duration: 0.3 }}
                              className="flex flex-col gap-6 items-center"
                            >
                              <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center text-nowrap">
                                <h2 className="block leading-[1.3] font-bold text-[24px] tracking-[-0.96px]">
                                  Gerador de logos
                                </h2>
                                <p className="block leading-[1.5] whitespace-pre font-medium text-[16px] text-[#636b7e] mt-2">
                                  Crie um logo provisório para começar a postar fretes agora mesmo.
                                </p>
                              </div>
                              <LogoGenerator />
                            </motion.div>
                          ) : (
                            <motion.div
                              key="converter"
                              initial={{ opacity: 0, x: 20 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -20 }}
                              transition={{ duration: 0.3 }}
                              className="flex flex-col gap-6 items-center"
                            >
                              <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center text-nowrap">
                                <h2 className="block leading-[1.3] font-bold text-[24px] tracking-[-0.96px]">
                                  Padronização de logos
                                </h2>
                                <p className="block leading-[1.5] whitespace-pre font-medium text-[16px] text-[#636b7e] mt-2">
                                  Ajuste seu logo existente para os formatos padrão exigidos.
                                </p>
                              </div>
                              <ImageConverter />
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </motion.div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}