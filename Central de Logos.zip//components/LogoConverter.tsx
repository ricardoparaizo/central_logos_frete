import React, { useState, useRef, useCallback } from 'react';
import { MainHeading, BodyText, SubHeading, NumberLabel } from './design-system/Typography';
import { PageContainer, ContentSection, CardSection, Divider, FlexRow, FlexColumn } from './design-system/Layout';
import { DesignButton, UploadArea, StatusBadge } from './design-system/Controls';
import { Download, CheckCircle } from 'lucide-react';

interface ConvertedImage {
  dataUrl: string;
  width: number;
  height: number;
  name: string;
}

export function LogoConverter() {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [originalFileName, setOriginalFileName] = useState<string>('');
  const [convertedImages, setConvertedImages] = useState<ConvertedImage[]>([]);
  const [isConverting, setIsConverting] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const handleFile = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Por favor, selecione um arquivo de imagem válido');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      setOriginalImage(e.target?.result as string);
      setOriginalFileName(file.name);
      setConvertedImages([]);
    };
    reader.readAsDataURL(file);
  }, []);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      handleFile(files[0]);
    }
  }, [handleFile]);

  const convertImage = useCallback(async (targetWidth: number, targetHeight: number) => {
    if (!originalImage) return null;

    return new Promise<ConvertedImage>((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        canvas.width = targetWidth;
        canvas.height = targetHeight;
        
        if (ctx) {
          // Fill canvas with white background
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, targetWidth, targetHeight);
          
          // Calculate aspect ratios
          const imgAspectRatio = img.width / img.height;
          const targetAspectRatio = targetWidth / targetHeight;
          
          let drawWidth, drawHeight, offsetX, offsetY;
          
          // Determine how to fit the image while preserving aspect ratio
          if (imgAspectRatio > targetAspectRatio) {
            // Image is wider than target, fit by width
            drawWidth = targetWidth;
            drawHeight = targetWidth / imgAspectRatio;
            offsetX = 0;
            offsetY = (targetHeight - drawHeight) / 2;
          } else {
            // Image is taller than target, fit by height
            drawHeight = targetHeight;
            drawWidth = targetHeight * imgAspectRatio;
            offsetX = (targetWidth - drawWidth) / 2;
            offsetY = 0;
          }
          
          // Use high-quality image scaling
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          
          // Draw the image with preserved aspect ratio
          ctx.drawImage(img, offsetX, offsetY, drawWidth, drawHeight);
          
          const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
          const fileName = originalFileName.replace(/\.[^/.]+$/, '') + `_${targetWidth}x${targetHeight}.jpg`;
          
          resolve({
            dataUrl,
            width: targetWidth,
            height: targetHeight,
            name: fileName
          });
        }
      };
      img.src = originalImage;
    });
  }, [originalImage, originalFileName]);

  const handleConvertAll = useCallback(async () => {
    if (!originalImage) return;
    
    setIsConverting(true);
    
    try {
      const conversions = await Promise.all([
        convertImage(100, 50),
        convertImage(400, 400)
      ]);
      
      setConvertedImages(conversions.filter(Boolean) as ConvertedImage[]);
    } catch (error) {
      console.error('Conversion error:', error);
    } finally {
      setIsConverting(false);
    }
  }, [convertImage, originalImage]);

  const downloadImage = useCallback((image: ConvertedImage) => {
    const link = document.createElement('a');
    link.download = image.name;
    link.href = image.dataUrl;
    link.click();
  }, []);

  const downloadAll = useCallback(() => {
    convertedImages.forEach(image => {
      setTimeout(() => downloadImage(image), 100);
    });
  }, [convertedImages, downloadImage]);

  return (
    <PageContainer>
      <ContentSection>
        {/* Header Section */}
        <FlexColumn additionalClassNames={["text-center items-center mb-16"]}>
          <MainHeading additionalClassNames={["mb-6"]}>
            Padronização de Logo
          </MainHeading>
          <BodyText size="large" additionalClassNames={["max-w-3xl text-center"]}>
            Converta seu logo para os formatos padrão de 100×50px e 400×400px exigidos no cadastro empresarial
          </BodyText>
        </FlexColumn>

        {/* How it Works Section */}
        <CardSection additionalClassNames={["mb-16"]}>
          <FlexRow additionalClassNames={["items-start"]}>
            <NumberLabel additionalClassNames={["flex-shrink-0"]}>01</NumberLabel>
            <FlexColumn additionalClassNames={["flex-1"]}>
              <SubHeading additionalClassNames={["mb-4"]}>
                Como funciona
              </SubHeading>
              <BodyText>
                Faça upload do logo da sua empresa e convertemos automaticamente para os dois formatos padrão exigidos: 
                100×50px para documentos e formulários, e 400×400px para perfis empresariais. 
                O logo mantém suas proporções originais com fundo branco. Todo processamento é feito no seu navegador - suas imagens não saem do seu dispositivo.
              </BodyText>
            </FlexColumn>
          </FlexRow>
        </CardSection>

        <Divider />

        {/* Upload Section */}
        <ContentSection additionalClassNames={["py-8"]}>
          <FlexRow additionalClassNames={["items-start"]}>
            <NumberLabel additionalClassNames={["flex-shrink-0"]}>02</NumberLabel>
            <FlexColumn additionalClassNames={["flex-1"]}>
              <SubHeading additionalClassNames={["mb-8"]}>
                Upload do Logo
              </SubHeading>
              <UploadArea
                onFileSelect={handleFile}
                dragActive={dragActive}
                onDragEnter={handleDrag}
                onDragLeave={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
              />
            </FlexColumn>
          </FlexRow>
        </ContentSection>

        {/* Original Image Preview */}
        {originalImage && (
          <>
            <Divider />
            <ContentSection additionalClassNames={["py-8"]}>
              <FlexRow additionalClassNames={["items-start"]}>
                <NumberLabel additionalClassNames={["flex-shrink-0"]}>03</NumberLabel>
                <FlexColumn additionalClassNames={["flex-1"]}>
                  <SubHeading additionalClassNames={["mb-8"]}>
                    Logo Original
                  </SubHeading>
                  <CardSection>
                    <FlexRow additionalClassNames={["items-start"]}>
                      <div className="flex-shrink-0">
                        <img
                          src={originalImage}
                          alt="Logo Original"
                          className="max-w-xs max-h-64 object-contain rounded-2xl border-2 border-[#dfe1e6]"
                        />
                      </div>
                      <FlexColumn additionalClassNames={["flex-1"]}>
                        <StatusBadge variant="secondary">
                          {originalFileName}
                        </StatusBadge>
                        <DesignButton
                          onClick={handleConvertAll}
                          disabled={isConverting}
                          size="large"
                        >
                          {isConverting ? 'Convertendo...' : 'Converter para Formatos Padrão'}
                        </DesignButton>
                        {isConverting && (
                          <div className="w-full bg-zinc-200 rounded-full h-2">
                            <div className="bg-[#111111] h-2 rounded-full animate-pulse w-1/2"></div>
                          </div>
                        )}
                      </FlexColumn>
                    </FlexRow>
                  </CardSection>
                </FlexColumn>
              </FlexRow>
            </ContentSection>
          </>
        )}

        {/* Converted Images */}
        {convertedImages.length > 0 && (
          <>
            <Divider />
            <ContentSection additionalClassNames={["py-8"]}>
              <FlexRow additionalClassNames={["items-start"]}>
                <NumberLabel additionalClassNames={["flex-shrink-0"]}>04</NumberLabel>
                <FlexColumn additionalClassNames={["flex-1"]}>
                  <FlexRow additionalClassNames={["items-center mb-8"]}>
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                      <SubHeading>Logos Convertidos</SubHeading>
                    </div>
                    <DesignButton
                      onClick={downloadAll}
                      variant="outline"
                      size="default"
                    >
                      <Download className="h-4 w-4" />
                      Baixar Todos
                    </DesignButton>
                  </FlexRow>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {convertedImages.map((image, index) => (
                      <CardSection key={index}>
                        <FlexColumn>
                          <div className="aspect-square bg-white rounded-2xl p-8 flex items-center justify-center border-2 border-[#dfe1e6] mb-4">
                            <img
                              src={image.dataUrl}
                              alt={`Logo ${image.width}x${image.height}`}
                              className="max-w-full max-h-full object-contain"
                              style={{
                                imageRendering: image.width === 100 ? 'pixelated' : 'auto'
                              }}
                            />
                          </div>
                          <FlexRow additionalClassNames={["items-center"]}>
                            <FlexColumn additionalClassNames={["flex-1"]}>
                              <StatusBadge variant="default">
                                {image.width} × {image.height}px
                              </StatusBadge>
                              <BodyText additionalClassNames={["text-[14px] mt-2"]}>
                                {image.name}
                              </BodyText>
                            </FlexColumn>
                            <DesignButton
                              size="small"
                              onClick={() => downloadImage(image)}
                              variant="outline"
                            >
                              <Download className="h-4 w-4" />
                              Baixar
                            </DesignButton>
                          </FlexRow>
                        </FlexColumn>
                      </CardSection>
                    ))}
                  </div>
                </FlexColumn>
              </FlexRow>
            </ContentSection>
          </>
        )}
      </ContentSection>
    </PageContainer>
  );
}