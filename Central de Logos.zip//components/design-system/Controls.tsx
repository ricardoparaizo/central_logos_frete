import React from 'react';
import clsx from "clsx";
import { Upload, Download } from 'lucide-react';

type ButtonProps = {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'default' | 'large' | 'small';
  additionalClassNames?: string[];
};

export function DesignButton({ 
  children, 
  onClick, 
  disabled = false, 
  variant = 'primary',
  size = 'default',
  additionalClassNames = [] 
}: ButtonProps) {
  const baseClasses = "font-['Satoshi:Medium',_sans-serif] rounded-2xl transition-all duration-200 cursor-pointer inline-flex items-center justify-center gap-2";
  
  const variants = {
    primary: "bg-[#111111] text-white hover:bg-[#333333] disabled:bg-[#babec9]",
    secondary: "bg-zinc-100 text-[#111111] hover:bg-zinc-200 disabled:bg-zinc-50",
    outline: "border-2 border-[#dfe1e6] bg-transparent text-[#636b7e] hover:border-[#111111] hover:text-[#111111] disabled:border-[#dfe1e6] disabled:text-[#babec9]"
  };
  
  const sizes = {
    small: "px-4 py-2 text-[14px] tracking-[-0.56px]",
    default: "px-6 py-3 text-[16px] tracking-[-0.64px]",
    large: "px-8 py-4 text-[18px] tracking-[-0.72px]"
  };

  return (
    <button
      className={clsx(
        baseClasses,
        variants[variant],
        sizes[size],
        disabled && "cursor-not-allowed",
        additionalClassNames
      )}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}

type UploadAreaProps = {
  onFileSelect: (file: File) => void;
  dragActive: boolean;
  onDragEnter: (e: React.DragEvent) => void;
  onDragLeave: (e: React.DragEvent) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent) => void;
  additionalClassNames?: string[];
};

export function UploadArea({
  onFileSelect,
  dragActive,
  onDragEnter,
  onDragLeave,
  onDragOver,
  onDrop,
  additionalClassNames = []
}: UploadAreaProps) {
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      onFileSelect(files[0]);
    }
  };

  return (
    <div
      className={clsx(
        "border-2 border-dashed rounded-2xl p-16 text-center transition-all duration-200",
        dragActive 
          ? 'border-[#111111] bg-zinc-50' 
          : 'border-[#dfe1e6] hover:border-[#babec9]',
        additionalClassNames
      )}
      onDragEnter={onDragEnter}
      onDragLeave={onDragLeave}
      onDragOver={onDragOver}
      onDrop={onDrop}
    >
      <Upload className="h-16 w-16 mx-auto mb-6 text-[#babec9]" />
      <div className="font-['Satoshi:Medium',_sans-serif] text-[24px] tracking-[-0.96px] text-[#636b7e] mb-4">
        Arraste e solte o logo da sua empresa aqui, ou
      </div>
      <DesignButton
        variant="outline"
        onClick={() => fileInputRef.current?.click()}
      >
        Selecionar Arquivo
      </DesignButton>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileInput}
        className="hidden"
      />
      <div className="font-['Satoshi:Regular',_sans-serif] text-[16px] tracking-[-0.64px] text-[#babec9] mt-4">
        Suporta JPG, PNG, GIF, WebP e outros formatos de imagem
      </div>
    </div>
  );
}

type StatusBadgeProps = {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'secondary';
  additionalClassNames?: string[];
};

export function StatusBadge({ children, variant = 'default', additionalClassNames = [] }: StatusBadgeProps) {
  const variants = {
    default: "bg-zinc-100 text-[#636b7e]",
    success: "bg-green-100 text-green-700",
    secondary: "bg-[#636b7e] text-white"
  };

  return (
    <div
      className={clsx(
        "font-['Satoshi:Medium',_sans-serif] text-[14px] tracking-[-0.56px] px-3 py-1 rounded-lg inline-block",
        variants[variant],
        additionalClassNames
      )}
    >
      {children}
    </div>
  );
}