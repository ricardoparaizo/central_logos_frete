import clsx from "clsx";

type HeadingProps = {
  children: React.ReactNode;
  additionalClassNames?: string[];
};

export function MainHeading({ children, additionalClassNames = [] }: HeadingProps) {
  return (
    <div
      className={clsx(
        "font-['Satoshi:Medium',_sans-serif] leading-[1.3] not-italic text-[#111111] text-[64px] text-left tracking-[-2.56px]",
        additionalClassNames,
      )}
    >
      <h1 className="adjustLetterSpacing block leading-[1.3]">{children}</h1>
    </div>
  );
}

export function SectionHeading({ children, additionalClassNames = [] }: HeadingProps) {
  return (
    <div
      className={clsx(
        "font-['Satoshi:Medium',_sans-serif] leading-[1.3] not-italic text-[#111111] text-[48px] text-left tracking-[-1.92px]",
        additionalClassNames,
      )}
    >
      <h2 className="adjustLetterSpacing block leading-[1.3]">{children}</h2>
    </div>
  );
}

export function SubHeading({ children, additionalClassNames = [] }: HeadingProps) {
  return (
    <div
      className={clsx(
        "font-['Satoshi:Medium',_sans-serif] leading-[1.3] not-italic text-[#111111] text-[32px] text-left tracking-[-1.28px]",
        additionalClassNames,
      )}
    >
      <h3 className="adjustLetterSpacing block leading-[1.3]">{children}</h3>
    </div>
  );
}

type BodyTextProps = {
  children: React.ReactNode;
  additionalClassNames?: string[];
  size?: 'default' | 'large';
};

export function BodyText({ children, additionalClassNames = [], size = 'default' }: BodyTextProps) {
  const textSize = size === 'large' ? 'text-[34px] tracking-[-1.36px]' : 'text-[18px] tracking-[-0.72px]';
  
  return (
    <div
      className={clsx(
        "font-['Satoshi:Medium',_sans-serif] leading-[1.3] not-italic text-[#636b7e]",
        textSize,
        "text-left",
        additionalClassNames,
      )}
    >
      <p className="adjustLetterSpacing block leading-[1.3]">{children}</p>
    </div>
  );
}

export function BrandText({ children, additionalClassNames = [] }: HeadingProps) {
  return (
    <div
      className={clsx(
        "font-['Satoshi:Bold',_sans-serif] leading-none not-italic opacity-70 text-[#babec9] text-left tracking-[-2.4px]",
        additionalClassNames,
      )}
    >
      <p className="leading-none text-[40px] whitespace-pre">
        <span>{`Fuel® `}</span>
        <span className="adjustLetterSpacing font-['Satoshi:Regular',_sans-serif] not-italic">
          Design System
        </span>
      </p>
    </div>
  );
}

export function NumberLabel({ children, additionalClassNames = [] }: HeadingProps) {
  return (
    <div
      className={clsx(
        "font-['Satoshi:Medium',_sans-serif] leading-[1.3] not-italic text-[#babec9] text-[36px] text-left tracking-[-1.44px]",
        additionalClassNames,
      )}
    >
      <p className="adjustLetterSpacing block leading-[1.3] whitespace-pre">
        {children}
      </p>
    </div>
  );
}