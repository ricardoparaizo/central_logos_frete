import clsx from "clsx";

type ContainerProps = {
  children: React.ReactNode;
  additionalClassNames?: string[];
};

export function PageContainer({ children, additionalClassNames = [] }: ContainerProps) {
  return (
    <div
      className={clsx(
        "bg-[#ffffff] overflow-clip relative rounded-3xl min-h-screen",
        additionalClassNames,
      )}
    >
      {children}
    </div>
  );
}

export function ContentSection({ children, additionalClassNames = [] }: ContainerProps) {
  return (
    <div
      className={clsx(
        "relative w-full max-w-[1760px] mx-auto px-20 py-16",
        additionalClassNames,
      )}
    >
      {children}
    </div>
  );
}

export function CardSection({ children, additionalClassNames = [] }: ContainerProps) {
  return (
    <div
      className={clsx(
        "bg-zinc-100 rounded-2xl p-16 w-full",
        additionalClassNames,
      )}
    >
      {children}
    </div>
  );
}

type DividerProps = {
  additionalClassNames?: string[];
};

export function Divider({ additionalClassNames = [] }: DividerProps) {
  return (
    <div
      className={clsx(
        "w-full my-8",
        additionalClassNames,
      )}
    >
      <div className="box-border content-stretch flex flex-col items-start justify-start px-0 py-4 relative w-full">
        <div
          className="bg-[#dfe1e6] h-px shrink-0 w-full"
          data-name="Divider"
        />
      </div>
    </div>
  );
}

export function FlexRow({ children, additionalClassNames = [] }: ContainerProps) {
  return (
    <div
      className={clsx(
        "flex flex-row items-start justify-between gap-8",
        additionalClassNames,
      )}
    >
      {children}
    </div>
  );
}

export function FlexColumn({ children, additionalClassNames = [] }: ContainerProps) {
  return (
    <div
      className={clsx(
        "flex flex-col items-start justify-start gap-6",
        additionalClassNames,
      )}
    >
      {children}
    </div>
  );
}