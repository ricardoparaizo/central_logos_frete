import React, { useState } from "react";
import { Menu, X, ChevronDown, User, LogIn } from "lucide-react";
import svgPaths from "../imports/svg-sdfc9naus6";

interface NavigationItem {
  label: string;
  href?: string;
  onClick?: () => void;
  hasDropdown?: boolean;
  dropdownItems?: { label: string; href: string }[];
  isActive?: boolean;
}

interface FretebrasStyleHeaderProps {
  onNavigate?: (page: "home" | "help") => void;
  currentPage?: "home" | "help";
}

function Logo({ onClick }: { onClick?: () => void }) {
  return (
    <div 
      className="relative shrink-0 cursor-pointer transition-opacity hover:opacity-80" 
      style={{ width: '140px', height: '44px' }} 
      onClick={onClick}
    >
      <svg
        className="block"
        width="140"
        height="44"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 150 48"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g>
          <path d={svgPaths.p37c5df00} fill="#00AEEF" />
          <path d={svgPaths.p3e9d6800} fill="#00AEEF" />
          <path d={svgPaths.p21669f00} fill="#00AEEF" />
          <path d={svgPaths.pea1f300} fill="#00AEEF" />
          <path d={svgPaths.p7776000} fill="#00AEEF" />
          <path d={svgPaths.p16e87c80} fill="#111111" />
          <path d={svgPaths.pae73960} fill="#111111" />
          <path d={svgPaths.p24356380} fill="#111111" />
          <path d={svgPaths.p3e298580} fill="#111111" />
          <path d={svgPaths.p1be3c880} fill="#111111" />
          <path d={svgPaths.p2f535800} fill="#111111" />
          <path d={svgPaths.p1e7d3280} fill="#111111" />
          <path d={svgPaths.p7bd1400} fill="#111111" />
          <path d={svgPaths.p467e3a0} fill="#111111" />
          <path d={svgPaths.p16216000} fill="#111111" />
          <path d={svgPaths.p1ef4a7c0} fill="#111111" />
          <path d={svgPaths.p7217380} fill="#111111" />
          <path d={svgPaths.p140d0280} fill="#111111" />
          <path d={svgPaths.p2a8b7580} fill="#111111" />
          <path d={svgPaths.p724e000} fill="#111111" />
          <path d={svgPaths.p276d3900} fill="#111111" />
        </g>
      </svg>
    </div>
  );
}

function NavigationLink({ item }: { item: NavigationItem }) {
  const baseClasses = "relative flex items-center gap-1 px-4 py-2 font-medium text-[15px] transition-all duration-200 cursor-pointer rounded-lg";
  const activeClasses = item.isActive 
    ? "text-[#0769da] bg-[#f0f7ff]" 
    : "text-[#111111] hover:text-[#0769da] hover:bg-[#f8f9fa]";

  if (item.onClick) {
    return (
      <div className={`${baseClasses} ${activeClasses}`} onClick={item.onClick}>
        {item.label}
        {item.hasDropdown && <ChevronDown className="w-4 h-4 ml-1" />}
        {item.isActive && (
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-[#0769da] rounded-full" />
        )}
      </div>
    );
  }

  return null;
}

function ActionButton({ 
  variant = "secondary", 
  children, 
  onClick,
  icon 
}: { 
  variant?: "primary" | "secondary";
  children: React.ReactNode;
  onClick?: () => void;
  icon?: React.ReactNode;
}) {
  const variants = {
    primary: "bg-[#0769da] text-white hover:bg-[#0651b3] border-[#0769da] shadow-sm",
    secondary: "bg-white text-[#111111] hover:bg-[#f8f9fa] border-[#dfe1e6] shadow-sm"
  };

  return (
    <button
      onClick={onClick}
      className={`
        flex items-center gap-2 px-5 py-2.5 rounded-lg font-medium text-[14px]
        border transition-all duration-200 ${variants[variant]}
      `}
    >
      {icon}
      {children}
    </button>
  );
}

function MobileMenu({ 
  isOpen, 
  onClose, 
  navigationItems, 
  onNavigate 
}: {
  isOpen: boolean;
  onClose: () => void;
  navigationItems: NavigationItem[];
  onNavigate?: (page: "home" | "help") => void;
}) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      <div className="fixed inset-0 bg-black/20" onClick={onClose} />
      <div className="fixed top-0 right-0 h-full w-80 bg-white shadow-xl">
        <div className="flex items-center justify-between p-6 border-b border-[#dfe1e6]">
          <Logo onClick={() => {
            onNavigate?.("home");
            onClose();
          }} />
          <button 
            onClick={onClose} 
            className="p-2 hover:bg-[#f8f9fa] rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="flex flex-col p-6 space-y-2">
          {navigationItems.map((item, index) => (
            <div 
              key={index} 
              className="py-1"
              onClick={() => {
                if (item.onClick) {
                  item.onClick();
                  onClose();
                }
              }}
            >
              <NavigationLink item={item} />
            </div>
          ))}
          
          <div className="pt-6 space-y-3 border-t border-[#dfe1e6] mt-4">
            <ActionButton 
              variant="primary"
              onClick={() => {
                window.open('https://sa2.fretebras.com.br/index.php#', '_blank');
                onClose();
              }}
            >
              Acessar Admin
            </ActionButton>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function FretebrasStyleHeader({ onNavigate, currentPage = "home" }: FretebrasStyleHeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navigationItems: NavigationItem[] = [
    {
      label: "Início",
      onClick: () => onNavigate?.("home"),
      isActive: currentPage === "home"
    },
    {
      label: "Como Funciona",
      hasDropdown: true,
      dropdownItems: [
        { label: "Para Transportadoras", href: "#" },
        { label: "Para Embarcadores", href: "#" }
      ]
    },
    {
      label: "Soluções",
      hasDropdown: true,
      dropdownItems: [
        { label: "Gestão de Fretes", href: "#" },
        { label: "Rastreamento", href: "#" },
        { label: "Documentos", href: "#" }
      ]
    },
    {
      label: "Ajuda",
      onClick: () => onNavigate?.("help"),
      isActive: currentPage === "help"
    },
    {
      label: "Acessar Admin",
      href: "https://sa2.fretebras.com.br/index.php#"
    }
  ];

  return (
    <header className="relative bg-white border-b border-[#dfe1e6] z-40 sticky top-0">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between px-6 py-4 lg:px-8">
          {/* Logo */}
          <div className="flex-shrink-0">
            <Logo onClick={() => onNavigate?.("home")} />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navigationItems.map((item, index) => (
              <NavigationLink key={index} item={item} />
            ))}
          </nav>

          {/* Desktop Action Buttons */}
          <div className="hidden lg:flex items-center space-x-3">
            <ActionButton 
              variant="primary"
              onClick={() => window.open('https://sa2.fretebras.com.br/index.php#', '_blank')}
            >
              Acessar Admin
            </ActionButton>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(true)}
            className="lg:hidden p-2 text-[#111111] hover:bg-[#f8f9fa] rounded-lg transition-colors"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <MobileMenu
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        navigationItems={navigationItems}
        onNavigate={onNavigate}
      />
    </header>
  );
}