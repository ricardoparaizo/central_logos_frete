import React, { useState, useRef, useCallback } from 'react';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Download, CheckCircle } from 'lucide-react';
import truckSvgPaths from '../imports/svg-e0k593zeaf';
import largeTruckSvgPaths from '../imports/svg-9axm1d5zon';

interface GeneratedLogo {
  dataUrl: string;
  width: number;
  height: number;
  name: string;
}

function TruckIcon({ size = 129 }: { size?: number }) {
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 48 48"
      >
        <g>
          <path
            d={truckSvgPaths.p10802f00}
            fill="#111111"
          />
          <path
            d={truckSvgPaths.p18a06480}
            fill="#111111"
          />
          <path
            d={truckSvgPaths.p2416b300}
            fill="#111111"
          />
        </g>
      </svg>
    </div>
  );
}

function Divider() {
  return (
    <div className="relative w-full">
      <div className="flex flex-col items-start justify-start p-0 relative w-full">
        <div className="bg-[#dfe1e6] h-px w-full" />
      </div>
    </div>
  );
}

export function LogoGenerator() {
  const [companyName, setCompanyName] = useState<string>('');
  const [generatedLogos, setGeneratedLogos] = useState<GeneratedLogo[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateLogo = useCallback(async (targetWidth: number, targetHeight: number) => {
    if (!companyName.trim()) return null;

    return new Promise<GeneratedLogo>((resolve) => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      canvas.width = targetWidth;
      canvas.height = targetHeight;
      
      if (ctx) {
        // Fill canvas with white background
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, targetWidth, targetHeight);
        
        // Apply border for 400x400 image (1px border)
        if (targetWidth === 400 && targetHeight === 400) {
          ctx.strokeStyle = '#dfe1e6';
          ctx.lineWidth = 1;
          ctx.strokeRect(0, 0, targetWidth, targetHeight);
        }
        
        // Choose the appropriate truck SVG and calculate dimensions based on specifications
        let svg: string;
        let iconSize: number;
        let contentArea: { x: number, y: number, width: number, height: number };
        let gap: number;
        
        if (targetWidth === 400 && targetHeight === 400) {
          // For 400x400: padding-left: 16px, padding-right: 16px, gap: 10px
          const horizontalPadding = 16;
          contentArea = {
            x: horizontalPadding,
            y: 0,
            width: targetWidth - (horizontalPadding * 2), // 400 - 32 = 368px
            height: targetHeight
          };
          gap = 10;
          iconSize = 129;
          
          svg = `<svg width="129" height="129" viewBox="0 0 129 129" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g>
              <path d="${largeTruckSvgPaths.p7d51140}" fill="#111111"/>
              <path d="${largeTruckSvgPaths.p1cb2af00}" fill="#111111"/>
              <path d="${largeTruckSvgPaths.p125f1000}" fill="#111111"/>
            </g>
          </svg>`;
        } else {
          // For 100x50: flex-direction: column, justify-content: center, align-items: center, gap: 2px
          contentArea = {
            x: 0,
            y: 0,
            width: targetWidth,
            height: targetHeight
          };
          gap = 2;
          iconSize = Math.min(targetWidth * 0.4, targetHeight * 0.5); // Smaller icon for 100x50
          
          svg = `<svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <g>
              <path d="${truckSvgPaths.p10802f00}" fill="#111111"/>
              <path d="${truckSvgPaths.p18a06480}" fill="#111111"/>
              <path d="${truckSvgPaths.p2416b300}" fill="#111111"/>
            </g>
          </svg>`;
        }
        
        const svgBlob = new Blob([svg], { type: 'image/svg+xml;charset=utf-8' });
        const svgUrl = URL.createObjectURL(svgBlob);
        
        const img = new Image();
        img.onload = () => {
          // Set up text properties
          ctx.fillStyle = '#111111';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          
          // Calculate font size based on format
          let fontSize: number;
          if (targetWidth === 400 && targetHeight === 400) {
            fontSize = 26;
            ctx.font = `bold ${fontSize}px "Satoshi", sans-serif`;
          } else {
            fontSize = Math.max(8, Math.min(12, targetWidth / (companyName.length * 0.8)));
            ctx.font = `bold ${fontSize}px "Satoshi", sans-serif`;
          }
          
          // Prepare text lines
          const maxWidth = contentArea.width * 0.9;
          const words = companyName.toUpperCase().split(' ');
          const lines: string[] = [];
          let currentLine = words[0];
          
          for (let i = 1; i < words.length; i++) {
            const testLine = currentLine + ' ' + words[i];
            const metrics = ctx.measureText(testLine);
            if (metrics.width > maxWidth) {
              lines.push(currentLine);
              currentLine = words[i];
            } else {
              currentLine = testLine;
            }
          }
          lines.push(currentLine);
          
          // Calculate total content height (icon + gap + text)
          const lineHeight = fontSize * 1.255;
          const totalTextHeight = lines.length * lineHeight;
          const totalContentHeight = iconSize + gap + totalTextHeight;
          
          // Center the entire content vertically within the content area (justify-content: center)
          const contentStartY = contentArea.y + (contentArea.height - totalContentHeight) / 2;
          
          // Position icon (align-items: center)
          const iconX = contentArea.x + (contentArea.width - iconSize) / 2;
          const iconY = contentStartY;
          
          // Draw the truck icon
          ctx.drawImage(img, iconX, iconY, iconSize, iconSize);
          
          // Position text (gap between icon and text)
          const textStartY = iconY + iconSize + gap;
          const textCenterX = contentArea.x + contentArea.width / 2;
          
          // Draw each line of text
          lines.forEach((line, index) => {
            const textY = textStartY + (index * lineHeight) + (lineHeight / 2);
            ctx.fillText(line, textCenterX, textY);
          });
          
          const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
          const fileName = `${companyName.toLowerCase().replace(/\s+/g, '_')}_logo_${targetWidth}x${targetHeight}.jpg`;
          
          resolve({
            dataUrl,
            width: targetWidth,
            height: targetHeight,
            name: fileName
          });
          
          URL.revokeObjectURL(svgUrl);
        };
        
        img.src = svgUrl;
      }
    });
  }, [companyName]);

  const handleGenerateLogos = useCallback(async () => {
    if (!companyName.trim()) {
      alert('Por favor, digite o nome da sua empresa');
      return;
    }
    
    setIsGenerating(true);
    
    try {
      const conversions = await Promise.all([
        generateLogo(100, 50),
        generateLogo(400, 400)
      ]);
      
      setGeneratedLogos(conversions.filter(Boolean) as GeneratedLogo[]);
    } catch (error) {
      console.error('Generation error:', error);
    } finally {
      setIsGenerating(false);
    }
  }, [generateLogo, companyName]);

  const downloadLogo = useCallback((logo: GeneratedLogo) => {
    const link = document.createElement('a');
    link.download = logo.name;
    link.href = logo.dataUrl;
    link.click();
  }, []);

  const downloadAll = useCallback(() => {
    generatedLogos.forEach(logo => {
      setTimeout(() => downloadLogo(logo), 100);
    });
  }, [generatedLogos, downloadLogo]);

  const resetGenerator = useCallback(() => {
    setCompanyName('');
    setGeneratedLogos([]);
  }, []);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    handleGenerateLogos();
  }, [handleGenerateLogos]);

  return (
    <div className="w-full">
      <div className="flex flex-col gap-8 items-center justify-start p-0 relative w-full px-[0px] py-[24px]">
        
        {/* Company Name Form */}
        <form onSubmit={handleSubmit} className="w-[488px]">
          <div className="space-y-2">
            <label 
              htmlFor="company-name"
              className="block text-xs text-[rgba(0,0,0,1)] font-medium text-[16px]"
            >
              Nome da sua empresa
            </label>
            <div className="relative">
              <input
                id="company-name"
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="Digite o nome da empresa"
                className="w-full h-12 px-4 bg-[rgba(0,43,92,0.06)] border-none rounded-2xl 
                         text-[var(--fuel-primary)] placeholder:text-[var(--fuel-secondary)]
                         focus:outline-none focus:ring-2 focus:ring-[var(--fuel-primary)]/20
                         transition-all duration-200"
                disabled={isGenerating}
              />
            </div>
          </div>
        </form>
        
        {/* Preview Section */}
        {companyName.trim() && (
          <div className="bg-white relative size-[400px] border border-[#babec9] border-solid">
            <div className="flex flex-col items-center justify-center relative size-full">
              <div className="flex flex-col gap-2.5 items-center justify-center px-4 py-0 relative size-[400px]">
                <TruckIcon />
                <div className="font-['Satoshi:Bold',_sans-serif] leading-[0] min-w-full not-italic relative text-[#111111] text-[26px] text-center tracking-[-1.04px] uppercase" style={{ width: "min-content" }}>
                  <p className="block leading-[1.255] text-[rgba(0,0,0,1)] font-bold text-[26px]">{companyName}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        {companyName.trim() && !generatedLogos.length && (
          <div className="flex flex-col gap-4 items-center">
            <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center">
              <p className="leading-[1.5] text-[16px] max-w-md mx-auto">
              </p>
            </div>
            
            <div className="flex flex-row gap-4 items-start justify-start p-0 relative">
              <button
                type="button"
                className="bg-[rgba(0,43,92,0.06)] h-12 px-4 rounded-full cursor-pointer hover:bg-[rgba(0,43,92,0.1)] transition-colors flex items-center justify-center"
                onClick={resetGenerator}
              >
                <span className="font-['Satoshi:Medium',_sans-serif] text-[#111111] text-[14px] whitespace-nowrap">
                  Criar novo logo
                </span>
              </button>
              
              <button
                type="button"
                className="bg-[#0769da] h-12 px-4 rounded-full cursor-pointer hover:bg-[#0556c7] transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={handleGenerateLogos}
                disabled={isGenerating}
              >
                <span className="font-['Satoshi:Medium',_sans-serif] text-white text-[14px] whitespace-nowrap">
                  {isGenerating ? 'Gerando...' : 'Baixar meu logo'}
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Progress */}
        {isGenerating && (
          <div className="w-full max-w-[488px]">
            <Progress value={50} className="w-full h-2 bg-[rgba(0,43,92,0.06)]" />
            <p className="text-center text-[#636b7e] text-sm mt-2">Gerando seus logos...</p>
          </div>
        )}

        {/* Results Section */}
        {generatedLogos.length > 0 && (
          <>
            <Divider />
            <div className="w-full">
              <div className="flex flex-col gap-6 items-center justify-start p-0 relative">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <p className="font-['Satoshi:Bold',_sans-serif] text-[#111111] text-[18px]">
                    Logos gerados
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
                  {generatedLogos.map((logo, index) => (
                    <div key={index} className="bg-[rgba(0,43,92,0.06)] rounded-2xl p-6">
                      <div className="flex flex-col items-center gap-4">
                        <div className="bg-white rounded-lg p-4 w-full flex items-center justify-center min-h-[120px]">
                          <img
                            src={logo.dataUrl}
                            alt={`Logo ${logo.width}x${logo.height}`}
                            className="max-w-full max-h-full object-contain"
                            style={{
                              imageRendering: logo.width === 100 ? 'pixelated' : 'auto'
                            }}
                          />
                        </div>
                        
                        <div className="flex flex-col items-center gap-2">
                          <Badge className="bg-white text-[#636b7e] border-[#dfe1e6]">
                            {logo.width} × {logo.height}px
                          </Badge>
                          <p className="text-[#636b7e] text-sm">{logo.name}</p>
                        </div>
                        
                        <button
                          className="bg-[#0769da] h-10 px-4 rounded-full cursor-pointer hover:bg-[#0556c7] transition-colors w-full flex items-center justify-center"
                          onClick={() => downloadLogo(logo)}
                        >
                          <Download className="h-4 w-4 mr-2 text-white" />
                          <span className="font-['Satoshi:Medium',_sans-serif] text-white text-[14px]">
                            Baixar
                          </span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {generatedLogos.length > 1 && (
                  <div className="flex flex-row gap-4">
                    <button
                      className="bg-[rgba(0,43,92,0.06)] h-12 px-6 rounded-full cursor-pointer hover:bg-[rgba(0,43,92,0.1)] transition-colors flex items-center justify-center"
                      onClick={resetGenerator}
                    >
                      <span className="font-['Satoshi:Medium',_sans-serif] text-[#111111] text-[14px]">
                        Criar novo logo
                      </span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}