import React, { useState, useCallback, useRef } from 'react';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Upload, Download, CheckCircle, X, Image as ImageIcon, AlertCircle, Shield } from 'lucide-react';

interface ConvertedLogo {
  dataUrl: string;
  width: number;
  height: number;
  name: string;
}

function Divider() {
  return (
    <div className="relative w-full">
      <div className="flex flex-col items-start justify-start p-0 relative w-full">
        <div className="bg-[#dfe1e6] h-px w-full" />
      </div>
    </div>
  );
}

export function ImageConverter() {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [convertedLogos, setConvertedLogos] = useState<ConvertedLogo[]>([]);
  const [isConverting, setIsConverting] = useState(false);
  const [currentProgress, setCurrentProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const resetConverter = useCallback(() => {
    setSelectedFile(null);
    setConvertedLogos([]);
    setIsConverting(false);
    setCurrentProgress(0);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, []);

  const triggerFileUpload = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Reset previous state
      setConvertedLogos([]);
      setError(null);
      setCurrentProgress(0);
      
      // Validate file type
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/svg+xml', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        setError('Formato de arquivo não suportado. Use PNG, JPG, JPEG, SVG ou WebP.');
        return;
      }
      
      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        setError('Arquivo muito grande. Tamanho máximo: 10MB.');
        return;
      }
      
      setSelectedFile(file);
    }
  }, []);

  const removeSelectedFile = useCallback(() => {
    setSelectedFile(null);
    setConvertedLogos([]);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, []);

  const processImageToLogo = useCallback((
    canvas: HTMLCanvasElement,
    ctx: CanvasRenderingContext2D,
    img: HTMLImageElement,
    width: number,
    height: number,
    name: string
  ): ConvertedLogo => {
    // Set canvas dimensions
    canvas.width = width;
    canvas.height = height;

    // Clear canvas with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    if (width === 400 && height === 400) {
      // 400x400 format: 10px gap, 16px horizontal padding, 1px border
      const borderWidth = 1;
      const padding = 16;
      const gap = 10;
      
      // Draw border
      ctx.strokeStyle = '#dfe1e6';
      ctx.lineWidth = borderWidth;
      ctx.strokeRect(borderWidth/2, borderWidth/2, width - borderWidth, height - borderWidth);
      
      // Calculate available space for image
      const availableWidth = width - (padding * 2) - (borderWidth * 2) - (gap * 2);
      const availableHeight = height - (gap * 2) - (borderWidth * 2);
      
      // Calculate image dimensions maintaining aspect ratio
      const aspectRatio = img.width / img.height;
      let drawWidth = availableWidth;
      let drawHeight = availableWidth / aspectRatio;
      
      if (drawHeight > availableHeight) {
        drawHeight = availableHeight;
        drawWidth = availableHeight * aspectRatio;
      }
      
      // Center the image
      const x = (width - drawWidth) / 2;
      const y = (height - drawHeight) / 2;
      
      ctx.drawImage(img, x, y, drawWidth, drawHeight);
    } else {
      // 100x50 format: flex column layout, centered, 2px gap
      const gap = 2;
      
      // Calculate image dimensions maintaining aspect ratio
      const aspectRatio = img.width / img.height;
      let drawWidth = width - (gap * 2);
      let drawHeight = (width - (gap * 2)) / aspectRatio;
      
      if (drawHeight > height - (gap * 2)) {
        drawHeight = height - (gap * 2);
        drawWidth = (height - (gap * 2)) * aspectRatio;
      }
      
      // Center the image
      const x = (width - drawWidth) / 2;
      const y = (height - drawHeight) / 2;
      
      ctx.drawImage(img, x, y, drawWidth, drawHeight);
    }

    return {
      dataUrl: canvas.toDataURL('image/jpeg', 0.95),
      width,
      height,
      name
    };
  }, []);

  const handleConvertLogos = useCallback(async () => {
    if (!selectedFile) return;

    setIsConverting(true);
    setCurrentProgress(0);
    setError(null);

    try {
      // Simulate progress steps
      const progressSteps = [10, 30, 50, 70, 90, 100];
      let stepIndex = 0;

      const progressInterval = setInterval(() => {
        if (stepIndex < progressSteps.length) {
          setCurrentProgress(progressSteps[stepIndex]);
          stepIndex++;
        }
      }, 300);

      // Create image from file
      const img = new Image();
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        throw new Error('Não foi possível criar contexto do canvas');
      }

      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error('Erro ao carregar imagem'));
        img.src = URL.createObjectURL(selectedFile);
      });

      // Generate both formats
      const logos: ConvertedLogo[] = [
        processImageToLogo(canvas, ctx, img, 400, 400, 'Logo Padrão 400x400'),
        processImageToLogo(canvas, ctx, img, 100, 50, 'Logo Compacto 100x50')
      ];

      clearInterval(progressInterval);
      setCurrentProgress(100);
      
      // Small delay to show completion
      setTimeout(() => {
        setConvertedLogos(logos);
        setIsConverting(false);
        URL.revokeObjectURL(img.src);
      }, 500);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro desconhecido na conversão');
      setIsConverting(false);
      setCurrentProgress(0);
    }
  }, [selectedFile, processImageToLogo]);

  const downloadLogo = useCallback((logo: ConvertedLogo) => {
    const link = document.createElement('a');
    link.download = `${logo.name.toLowerCase().replace(/\s+/g, '-')}-${logo.width}x${logo.height}.jpg`;
    link.href = logo.dataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }, []);

  return (
    <div className="w-full">
      <div className="flex flex-col gap-8 items-center justify-start p-0 relative w-full px-[0px] py-[24px]">
        
        {/* File Upload Section */}
        <div className="w-[488px]">
          <div className="space-y-6">
            {/* File Upload Field */}
            <div className="space-y-2">
              <label 
                htmlFor="file-upload"
                className="block text-xs text-[rgba(0,0,0,1)] font-medium text-[16px]"
              >
                Envie sua imagem
              </label>
              
              <input
                ref={fileInputRef}
                id="file-upload"
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
                disabled={isConverting}
              />
              
              {!selectedFile ? (
                <div 
                  className="w-full h-32 border-2 border-dashed border-[#dfe1e6] bg-[rgba(0,43,92,0.06)] rounded-2xl 
                           hover:border-[#0769da] hover:bg-[rgba(7,105,218,0.08)] transition-all duration-200 
                           cursor-pointer flex flex-col items-center justify-center gap-3"
                  onClick={triggerFileUpload}
                >
                  <Upload className="h-6 w-6 text-[#636b7e]" />
                  <div className="text-center">
                    <p className="text-[14px] text-[#111111] font-medium">
                      Clique para enviar imagem
                    </p>
                    <p className="text-[12px] text-[#636b7e] mt-1">
                      PNG, JPG, JPEG, SVG, WebP
                    </p>
                  </div>
                </div>
              ) : (
                <div className="w-full bg-[rgba(0,43,92,0.06)] rounded-2xl p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <ImageIcon className="h-5 w-5 text-blue-500" />
                      <div>
                        <p className="text-[14px] text-[#111111] font-medium truncate max-w-[280px]">
                          {selectedFile.name}
                        </p>
                        <p className="text-[12px] text-[#636b7e]">
                          Imagem • {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={removeSelectedFile}
                      className="h-8 w-8 rounded-full bg-[rgba(0,0,0,0.1)] hover:bg-[rgba(0,0,0,0.2)] 
                               transition-colors flex items-center justify-center"
                      disabled={isConverting}
                    >
                      <X className="h-4 w-4 text-[#636b7e]" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Process Info */}
        {selectedFile && !convertedLogos.length && !isConverting && !error && (
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-6 w-[488px]">
            <div className="flex items-center gap-3">
              <div className="bg-blue-500 rounded-full p-2">
                <ImageIcon className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-[16px] text-blue-800">Padronização de Logo</h3>
                <p className="text-[14px] text-blue-600">Formatação automática para os padrões exigidos</p>
              </div>
            </div>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-6 w-[488px]">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-red-500 rounded-full p-2">
                <AlertCircle className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-[16px] text-red-800">Erro na Conversão</h3>
                <p className="text-[14px] text-red-600">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        {selectedFile && !convertedLogos.length && !isConverting && (
          <div className="flex flex-col gap-4 items-center">
            <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center text-nowrap">
              <p className="leading-[1.5] text-[16px] whitespace-pre">
                <span className="font-['Satoshi:Bold',_sans-serif] font-[Satoshi]">Pronto! </span>
                <span className="font-['Satoshi:Medium',_sans-serif] not-italic font-[Satoshi]">
                  Vamos padronizar seu logo.
                </span>
              </p>
            </div>
            
            <div className="flex flex-row gap-4 items-start justify-start p-0 relative">
              <button
                type="button"
                className="bg-[rgba(0,43,92,0.06)] h-12 px-4 rounded-full cursor-pointer hover:bg-[rgba(0,43,92,0.1)] transition-colors flex items-center justify-center"
                onClick={resetConverter}
              >
                <span className="font-['Satoshi:Medium',_sans-serif] text-[#111111] text-[14px] whitespace-nowrap">
                  Limpar
                </span>
              </button>
              
              <button
                type="button"
                className="bg-[#0769da] h-12 px-6 rounded-full cursor-pointer hover:bg-[#0556c7] transition-colors flex items-center justify-center gap-2"
                onClick={handleConvertLogos}
              >
                <ImageIcon className="h-4 w-4 text-white" />
                <span className="font-['Satoshi:Medium',_sans-serif] text-white text-[14px] whitespace-nowrap">
                  Padronizar logo
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Progress */}
        {isConverting && (
          <div className="w-full max-w-[488px]">
            <div className="bg-[rgba(0,43,92,0.06)] rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-[#0769da] rounded-full p-2 animate-pulse">
                  <ImageIcon className="h-4 w-4 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-[14px] text-[#111111]">
                    Padronizando logo...
                  </h4>
                  <p className="text-[12px] text-[#636b7e]">
                    Aplicando especificações padrão
                  </p>
                </div>
              </div>
              <Progress 
                value={currentProgress} 
                className="w-full h-2 bg-[rgba(0,43,92,0.06)]" 
              />
              <p className="text-center text-[#636b7e] text-sm mt-3">
                {currentProgress < 30 ? 'Carregando imagem...' : 
                 currentProgress < 70 ? 'Redimensionando e aplicando formatação...' : 
                 'Finalizando conversão para JPG...'}
              </p>
            </div>
          </div>
        )}

        {/* Results Section */}
        {convertedLogos.length > 0 && (
          <>
            <Divider />
            <div className="w-full">
              <div className="flex flex-col gap-6 items-center justify-start p-0 relative">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <p className="font-['Satoshi:Bold',_sans-serif] text-[#111111] text-[18px]">
                    Logo padronizado com sucesso
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
                  {convertedLogos.map((logo, index) => (
                    <div key={index} className="bg-[rgba(0,43,92,0.06)] rounded-2xl p-6">
                      <div className="flex flex-col items-center gap-4">
                        <div className="bg-white rounded-lg p-4 w-full flex items-center justify-center min-h-[120px] shadow-sm border">
                          <img
                            src={logo.dataUrl}
                            alt={`Logo padronizado ${logo.width}x${logo.height}`}
                            className="max-w-full max-h-full object-contain"
                            style={{
                              imageRendering: 'auto'
                            }}
                          />
                        </div>
                        
                        <div className="flex flex-col items-center gap-2 w-full">
                          <Badge className="bg-[#0769da] text-white border-none">
                            {logo.width} × {logo.height}px • JPG
                          </Badge>
                          <p className="text-[#636b7e] text-sm text-center font-medium">{logo.name}</p>
                          <p className="text-[#636b7e] text-xs text-center italic px-2 leading-relaxed">
                            {logo.width === 400
                              ? 'Formato padrão com 10px padding e 1px border'
                              : 'Formato compacto otimizado'
                            }
                          </p>
                        </div>
                        
                        <button
                          className="bg-[#0769da] h-10 px-4 rounded-full cursor-pointer hover:bg-[#0556c7] transition-colors w-full flex items-center justify-center"
                          onClick={() => downloadLogo(logo)}
                        >
                          <Download className="h-4 w-4 mr-2 text-white" />
                          <span className="font-['Satoshi:Medium',_sans-serif] text-white text-[14px]">
                            Baixar JPG
                          </span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {convertedLogos.length > 1 && (
                  <div className="flex flex-row gap-4">
                    <button
                      className="bg-[rgba(0,43,92,0.06)] h-12 px-6 rounded-full cursor-pointer hover:bg-[rgba(0,43,92,0.1)] transition-colors flex items-center justify-center"
                      onClick={resetConverter}
                    >
                      <span className="font-['Satoshi:Medium',_sans-serif] text-[#111111] text-[14px]">
                        Processar outra imagem
                      </span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>

      {/* LGPD Footer Warning */}
      <div className="w-full border-t border-[#dfe1e6] bg-[rgba(248,249,250,0)] px-6 py-4 mt-8">
        <div className="flex items-center justify-center gap-3 max-w-2xl mx-auto">
          <Shield className="h-4 w-4 text-[#636b7e] flex-shrink-0" />
          <p className="text-[14px] text-[#636b7e] text-center leading-relaxed text-[14px] text-[13px]">
            <span className="font-medium text-[#111111] text-[16px]">Atenção:</span> não utilizar logo com informações sensíveis fora das normas LGPD.
          </p>
        </div>
      </div>
    </div>
  );
}