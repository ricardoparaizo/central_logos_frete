import React, { useState, useCallback } from 'react';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Download, CheckCircle, Sparkles, Wand2, AlertCircle, Palette } from 'lucide-react';

interface GeneratedLogo {
  dataUrl: string;
  width: number;
  height: number;
  name: string;
  prompt: string;
}

function Divider() {
  return (
    <div className="relative w-full">
      <div className="flex flex-col items-start justify-start p-0 relative w-full">
        <div className="bg-[#dfe1e6] h-px w-full" />
      </div>
    </div>
  );
}

// Function to create optimized logo prompts with custom description
const createLogoPrompt = (companyName: string, customDescription?: string): string => {
  const basePrompt = `professional minimalist logo design for "${companyName}" company`;
  
  if (customDescription && customDescription.trim()) {
    return `${basePrompt}, ${customDescription.trim()}, vector style, clean design, professional branding, white background, high quality, corporate identity, modern aesthetic, simple and elegant, business logo, minimalist`;
  }
  
  const defaultPrompts = [
    `${basePrompt}, modern minimalist vector logo, clean geometric shapes, professional corporate branding, white background, high quality design, business logo`,
    `${basePrompt}, sleek contemporary logo design, abstract symbol, professional typography, vector style, white background, corporate identity, brand mark`,
    `${basePrompt}, creative business logo, modern clean lines, professional branding, minimalist approach, vector design, white background, company logo`,
    `${basePrompt}, elegant corporate logo, geometric elements, clean typography, professional appearance, vector style, white background, brand identity`,
    `${basePrompt}, sophisticated brand identity, modern design language, clean vector style, professional corporate look, white background, logo mark`
  ];
  
  return defaultPrompts[Math.floor(Math.random() * defaultPrompts.length)];
};

// Function to load image and convert to canvas
const loadImageToCanvas = (src: string): Promise<HTMLCanvasElement> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }
      
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      resolve(canvas);
    };
    img.onerror = (error) => {
      console.error('Image loading error:', error);
      reject(new Error('Failed to load image'));
    };
    img.src = src;
  });
};

// Function to resize and crop image to specific dimensions
const resizeImageToFormat = async (originalCanvas: HTMLCanvasElement, targetWidth: number, targetHeight: number, companyName: string): Promise<string> => {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Could not get canvas context');
  }
  
  canvas.width = targetWidth;
  canvas.height = targetHeight;
  
  // Fill with white background
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, targetWidth, targetHeight);
  
  // Calculate scaling to fit the image properly
  const sourceRatio = originalCanvas.width / originalCanvas.height;
  const targetRatio = targetWidth / targetHeight;
  
  let drawWidth, drawHeight, offsetX, offsetY;
  
  if (sourceRatio > targetRatio) {
    drawHeight = targetHeight * 0.85;
    drawWidth = drawHeight * sourceRatio;
    offsetX = (targetWidth - drawWidth) / 2;
    offsetY = (targetHeight - drawHeight) / 2;
  } else {
    drawWidth = targetWidth * 0.85;
    drawHeight = drawWidth / sourceRatio;
    offsetX = (targetWidth - drawWidth) / 2;
    offsetY = (targetHeight - drawHeight) / 2;
  }
  
  // Draw the resized image
  ctx.drawImage(originalCanvas, offsetX, offsetY, drawWidth, drawHeight);
  
  // Add company name if it's the smaller format
  if (targetHeight === 50 && companyName) {
    ctx.fillStyle = '#111111';
    ctx.font = 'bold 8px "Satoshi", Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    
    const textY = targetHeight - 5;
    ctx.fillText(companyName.toUpperCase(), targetWidth / 2, textY);
  }
  
  return canvas.toDataURL('image/jpeg', 0.9);
};

// Generate base AI logo (single image generation)
const generateBaseAILogo = async (companyName: string, customDescription?: string): Promise<{ canvas: HTMLCanvasElement, prompt: string }> => {
  const prompt = createLogoPrompt(companyName, customDescription);
  const seed = Math.floor(Math.random() * 2147483647);
  
  // Array of API endpoints to try in order
  const apiEndpoints = [
    // Primary: Pollinations with Flux model
    {
      url: `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&model=flux&enhance=true&safe=true&nologo=true&seed=${seed}`,
      method: 'GET' as const,
      name: 'Pollinations Flux'
    },
    // Fallback 1: Different Pollinations configuration with same seed
    {
      url: `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&model=turbo&enhance=true&safe=true&seed=${seed}`,
      method: 'GET' as const,
      name: 'Pollinations Turbo'
    },
    // Fallback 2: Another variation with same seed
    {
      url: `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&enhance=true&safe=true&seed=${seed}`,
      method: 'GET' as const,
      name: 'Pollinations Default'
    }
  ];

  for (const api of apiEndpoints) {
    try {
      console.log(`Trying ${api.name}...`);
      
      const response = await fetch(api.url, {
        method: 'GET',
        headers: {
          'Accept': 'image/*',
          'User-Agent': 'Mozilla/5.0 (compatible; LogoAI/1.0)'
        },
      });

      if (!response.ok) {
        console.warn(`${api.name} failed with status: ${response.status}`);
        continue;
      }

      const blob = await response.blob();
      if (!blob.type.startsWith('image/')) {
        console.warn(`${api.name} returned non-image response`);
        continue;
      }

      const imageUrl = URL.createObjectURL(blob);
      const originalCanvas = await loadImageToCanvas(imageUrl);
      URL.revokeObjectURL(imageUrl);
      
      console.log(`Successfully generated base logo using ${api.name}`);
      
      return {
        canvas: originalCanvas,
        prompt: prompt
      };
      
    } catch (error) {
      console.error(`${api.name} failed:`, error);
      continue;
    }
  }
  
  // If all APIs fail, throw an error
  throw new Error('Todas as APIs de geração de imagem estão temporariamente indisponíveis. Tente novamente em alguns minutos.');
};

// Generate both formats from base image
const generateLogoFormats = async (companyName: string, customDescription?: string): Promise<GeneratedLogo[]> => {
  // Generate single base image
  const { canvas: baseCanvas, prompt } = await generateBaseAILogo(companyName, customDescription);
  
  // Create both formats from the same base image
  const logo400Data = await resizeImageToFormat(baseCanvas, 400, 400, companyName);
  const logo100Data = await resizeImageToFormat(baseCanvas, 100, 50, companyName);
  
  const logos: GeneratedLogo[] = [
    {
      dataUrl: logo100Data,
      width: 100,
      height: 50,
      name: `${companyName.toLowerCase().replace(/\s+/g, '_')}_ai_logo_100x50.jpg`,
      prompt: prompt
    },
    {
      dataUrl: logo400Data,
      width: 400,
      height: 400,
      name: `${companyName.toLowerCase().replace(/\s+/g, '_')}_ai_logo_400x400.jpg`,
      prompt: prompt
    }
  ];
  
  return logos;
};

export function AILogoGenerator() {
  const [companyName, setCompanyName] = useState<string>('');
  const [customDescription, setCustomDescription] = useState<string>('');
  const [generatedLogos, setGeneratedLogos] = useState<GeneratedLogo[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentProgress, setCurrentProgress] = useState(0);
  const [error, setError] = useState<string>('');

  const handleGenerateLogos = useCallback(async () => {
    if (!companyName.trim()) {
      alert('Por favor, digite o nome da sua empresa');
      return;
    }
    
    setIsGenerating(true);
    setCurrentProgress(0);
    setError('');
    
    try {
      // Progress simulation
      const progressInterval = setInterval(() => {
        setCurrentProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + Math.random() * 10;
        });
      }, 500);
      
      // Generate both formats from single base image
      setCurrentProgress(20);
      const logos = await generateLogoFormats(companyName, customDescription);
      
      clearInterval(progressInterval);
      setCurrentProgress(100);
      
      setGeneratedLogos(logos);
      
    } catch (error) {
      console.error('AI Generation error:', error);
      setError(error instanceof Error ? error.message : 'Erro na geração do logo. Tente novamente.');
    } finally {
      setTimeout(() => {
        setIsGenerating(false);
        setCurrentProgress(0);
      }, 500);
    }
  }, [companyName, customDescription]);

  const downloadLogo = useCallback((logo: GeneratedLogo) => {
    const link = document.createElement('a');
    link.download = logo.name;
    link.href = logo.dataUrl;
    link.click();
  }, []);

  const resetGenerator = useCallback(() => {
    setCompanyName('');
    setCustomDescription('');
    setGeneratedLogos([]);
    setError('');
  }, []);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    handleGenerateLogos();
  }, [handleGenerateLogos]);

  return (
    <div className="w-full">
      <div className="flex flex-col gap-8 items-center justify-start p-0 relative w-full px-[0px] py-[24px]">
        
        {/* Company Name and Description Form */}
        <form onSubmit={handleSubmit} className="w-[488px]">
          <div className="space-y-6">
            {/* Company Name Field */}
            <div className="space-y-2">
              <label 
                htmlFor="ai-company-name"
                className="block text-xs text-[rgba(0,0,0,1)] font-medium text-[16px]"
              >
                Nome da sua empresa
              </label>
              <div className="relative">
                <input
                  id="ai-company-name"
                  type="text"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="Digite o nome da empresa"
                  className="w-full h-12 px-4 bg-[rgba(0,43,92,0.06)] border-none rounded-2xl 
                           text-[var(--fuel-primary)] placeholder:text-[var(--fuel-secondary)]
                           focus:outline-none focus:ring-2 focus:ring-[var(--fuel-primary)]/20
                           transition-all duration-200"
                  disabled={isGenerating}
                />
                <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
                  <Sparkles className="h-4 w-4 text-[#636b7e]" />
                </div>
              </div>
            </div>

            {/* Custom Description Field */}
            <div className="space-y-2">
              <label 
                htmlFor="ai-custom-description"
                className="block text-xs text-[rgba(0,0,0,1)] font-medium text-[16px]"
              >
                Características da marca <span className="text-[#636b7e] font-normal">(opcional)</span>
              </label>
              <div className="relative">
                <textarea
                  id="ai-custom-description"
                  value={customDescription}
                  onChange={(e) => setCustomDescription(e.target.value)}
                  placeholder="Ex: cores azul e branco, segmento logística, formas geométricas modernas, estilo minimalista..."
                  rows={3}
                  className="w-full px-4 py-3 bg-[rgba(0,43,92,0.06)] border-none rounded-2xl 
                           text-[var(--fuel-primary)] placeholder:text-[var(--fuel-secondary)]
                           focus:outline-none focus:ring-2 focus:ring-[var(--fuel-primary)]/20
                           transition-all duration-200 resize-none"
                  disabled={isGenerating}
                />
                <div className="absolute right-4 top-3">
                  <Palette className="h-4 w-4 text-[#636b7e]" />
                </div>
              </div>
              <p className="text-[#636b7e] text-xs leading-relaxed">
                Descreva cores, segmento empresarial, formas ou estilo preferido para personalizar seu logo
              </p>
            </div>
          </div>
        </form>

        {/* AI Info Section */}
        {companyName.trim() && !generatedLogos.length && !isGenerating && !error && (
          <div className="bg-gradient-to-r from-[#0769da]/5 to-[#6366f1]/5 rounded-2xl p-6 w-[488px]">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-gradient-to-r from-[#0769da] to-[#6366f1] rounded-full p-2">
                <Wand2 className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-[16px] text-[#111111]">Logo AI Sync</h3>
                <p className="text-[14px] text-[#636b7e]">Formatos sincronizados</p>
              </div>
            </div>
            <p className="text-[14px] text-[#636b7e] leading-[1.4]">
              Nossa IA criará um logo único para <strong className="text-[#111111]">{companyName}</strong>
              {customDescription.trim() && (
                <span> usando suas características: <em className="text-[#111111]">"{customDescription.trim().substring(0, 60)}..."</em></span>
              )}
              {!customDescription.trim() && (
                <span> com design profissional</span>
              )}. Os dois formatos terão <strong className="text-[#111111]">exatamente o mesmo design</strong> para garantir consistência visual.
            </p>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-6 w-[488px]">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-red-500 rounded-full p-2">
                <AlertCircle className="h-4 w-4 text-white" />
              </div>
              <div>
                <h3 className="font-bold text-[16px] text-red-800">Erro na Geração</h3>
                <p className="text-[14px] text-red-600">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        {companyName.trim() && !generatedLogos.length && !isGenerating && (
          <div className="flex flex-col gap-4 items-center">
            <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center text-nowrap">
              <p className="leading-[1.5] text-[16px] whitespace-pre">
                <span className="font-['Satoshi:Bold',_sans-serif] font-[Satoshi]">Pronto! </span>
                <span className="font-['Satoshi:Medium',_sans-serif] not-italic font-[Satoshi]">
                  {customDescription.trim() ? 'Vamos gerar seu logo personalizado.' : 'Vamos gerar seu logo sincronizado.'}
                </span>
              </p>
            </div>
            
            <div className="flex flex-row gap-4 items-start justify-start p-0 relative">
              <button
                type="button"
                className="bg-[rgba(0,43,92,0.06)] h-12 px-4 rounded-full cursor-pointer hover:bg-[rgba(0,43,92,0.1)] transition-colors flex items-center justify-center"
                onClick={resetGenerator}
              >
                <span className="font-['Satoshi:Medium',_sans-serif] text-[#111111] text-[14px] whitespace-nowrap">
                  Limpar
                </span>
              </button>
              
              <button
                type="button"
                className="bg-gradient-to-r from-[#0769da] to-[#6366f1] h-12 px-6 rounded-full cursor-pointer hover:from-[#0556c7] hover:to-[#5855eb] transition-all duration-200 flex items-center justify-center gap-2 shadow-lg"
                onClick={handleGenerateLogos}
              >
                <Sparkles className="h-4 w-4 text-white" />
                <span className="font-['Satoshi:Medium',_sans-serif] text-white text-[14px] whitespace-nowrap">
                  {customDescription.trim() ? 'Gerar Personalizado' : 'Gerar Sincronizado'}
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Progress */}
        {isGenerating && (
          <div className="w-full max-w-[488px]">
            <div className="bg-gradient-to-r from-[#0769da]/10 to-[#6366f1]/10 rounded-2xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-gradient-to-r from-[#0769da] to-[#6366f1] rounded-full p-2 animate-pulse">
                  <Wand2 className="h-4 w-4 text-white" />
                </div>
                <div>
                  <h4 className="font-bold text-[14px] text-[#111111]">IA Sync gerando...</h4>
                  <p className="text-[12px] text-[#636b7e]">
                    Criando design único para ambos os formatos
                  </p>
                </div>
              </div>
              <Progress 
                value={currentProgress} 
                className="w-full h-2 bg-[rgba(0,43,92,0.06)]" 
              />
              <p className="text-center text-[#636b7e] text-sm mt-3">
                {currentProgress < 40 ? 'Gerando design base com IA...' : 
                 currentProgress < 80 ? 'Adaptando para formatos 400x400 e 100x50...' : 
                 'Finalizando logos sincronizados...'}
              </p>
            </div>
          </div>
        )}

        {/* Results Section */}
        {generatedLogos.length > 0 && (
          <>
            <Divider />
            <div className="w-full">
              <div className="flex flex-col gap-6 items-center justify-start p-0 relative">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <p className="font-['Satoshi:Bold',_sans-serif] text-[#111111] text-[18px]">
                    Logos sincronizados criados com IA
                  </p>
                </div>
                
                <div className="bg-gradient-to-r from-[#0769da]/5 to-[#6366f1]/5 rounded-2xl p-4 w-full">
                  <p className="text-[14px] text-[#636b7e] text-center">
                    ✨ <strong className="text-[#111111]">Design idêntico</strong> em ambos os formatos para máxima consistência visual
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
                  {generatedLogos.map((logo, index) => (
                    <div key={index} className="bg-gradient-to-br from-[rgba(0,43,92,0.06)] to-[rgba(103,102,241,0.06)] rounded-2xl p-6">
                      <div className="flex flex-col items-center gap-4">
                        <div className="bg-white rounded-lg p-4 w-full flex items-center justify-center min-h-[120px] shadow-sm border">
                          <img
                            src={logo.dataUrl}
                            alt={`Logo AI Sync ${logo.width}x${logo.height}`}
                            className="max-w-full max-h-full object-contain"
                            style={{
                              imageRendering: 'auto'
                            }}
                          />
                        </div>
                        
                        <div className="flex flex-col items-center gap-2 w-full">
                          <Badge className="bg-gradient-to-r from-[#0769da] to-[#6366f1] text-white border-none">
                            {logo.width} × {logo.height}px • Sincronizado
                          </Badge>
                          <p className="text-[#636b7e] text-sm text-center font-medium">{logo.name}</p>
                          <p className="text-[#636b7e] text-xs text-center italic px-2 leading-relaxed">
                            Mesmo design, formato otimizado
                          </p>
                        </div>
                        
                        <button
                          className="bg-gradient-to-r from-[#0769da] to-[#6366f1] h-10 px-4 rounded-full cursor-pointer hover:from-[#0556c7] hover:to-[#5855eb] transition-all duration-200 w-full flex items-center justify-center shadow-lg"
                          onClick={() => downloadLogo(logo)}
                        >
                          <Download className="h-4 w-4 mr-2 text-white" />
                          <span className="font-['Satoshi:Medium',_sans-serif] text-white text-[14px]">
                            Baixar JPG
                          </span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {generatedLogos.length > 1 && (
                  <div className="flex flex-row gap-4">
                    <button
                      className="bg-[rgba(0,43,92,0.06)] h-12 px-6 rounded-full cursor-pointer hover:bg-[rgba(0,43,92,0.1)] transition-colors flex items-center justify-center"
                      onClick={resetGenerator}
                    >
                      <span className="font-['Satoshi:Medium',_sans-serif] text-[#111111] text-[14px]">
                        Gerar novos logos
                      </span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}