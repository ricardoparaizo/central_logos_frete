import React, { useState } from "react";
import svgPaths from "../imports/svg-ax4nfu75ds";
import questionSvgPaths from "../imports/svg-u6fr1fhhiq";

function QuestionIcon() {
  return (
    <div className="relative size-5">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 40 40"
      >
        <path
          d={questionSvgPaths.p3615e380}
          fill="white"
        />
      </svg>
    </div>
  );
}

function IconButton() {
  return (
    <div
      className="relative rounded-full size-12"
      style={{
        backgroundImage:
          "linear-gradient(47.3859deg, rgb(7, 105, 218) 13.831%, rgb(206, 220, 255) 88.961%)",
      }}
    >
      <div className="flex flex-row items-center justify-center p-0 relative size-12">
        <QuestionIcon />
      </div>
    </div>
  );
}

interface AccordionItemProps {
  question: string;
  answer: React.ReactNode;
  isOpen: boolean;
  onToggle: () => void;
}

function AccordionItem({ question, answer, isOpen, onToggle }: AccordionItemProps) {
  return (
    <div className="bg-[#ffffff] relative shrink-0 w-full">
      <div className="absolute border-[#dfe1e6] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-col justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-center px-0 py-6 relative w-full">
          {/* Question Header */}
          <div 
            className="relative shrink-0 w-full cursor-pointer"
            onClick={onToggle}
          >
            <div className="box-border content-stretch flex flex-row gap-6 items-center justify-start p-0 relative w-full">
              <div className="basis-0 font-['Satoshi:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#111111] text-[16px] text-left">
                <p className="block leading-[1.5] text-[16px] text-[rgba(17,17,17,1)]">{question}</p>
              </div>
              <div className="flex flex-row items-center self-stretch">
                <div className="h-full relative shrink-0">
                  <div className="flex flex-row justify-end relative size-full">
                    <div className="box-border content-stretch flex flex-row gap-2.5 h-full items-start justify-end px-0 py-0.5 relative">
                      <div className="relative shrink-0 size-5">
                        <svg
                          className={`block size-full transition-transform duration-200 ${isOpen ? 'rotate-45' : ''}`}
                          fill="none"
                          preserveAspectRatio="none"
                          viewBox="0 0 20 20"
                        >
                          <g>
                            <path
                              d="M10 2.5V17.5M2.5 10H17.5"
                              stroke="#636B7E"
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              strokeWidth="1.25"
                            />
                          </g>
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Answer Section */}
          {isOpen && (
            <div className="relative shrink-0 w-full">
              <div className="relative size-full">
                <div className="box-border content-stretch flex flex-row gap-2.5 items-start justify-start pl-0 pr-5 py-0 relative w-full">
                  <div className="basis-0 font-['Satoshi:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#636b7e] text-[0px] text-left">
                    <div className="leading-[1.5] text-[14px]">{answer}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Divider() {
  return (
    <div className="relative w-full">
      <div className="flex flex-col items-start justify-start p-0 relative w-full">
        <div className="bg-[#dfe1e6] h-px w-full" />
      </div>
    </div>
  );
}

export function Help() {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const faqItems = [
    {
      question: "Como faço para criar o meu logo?",
      answer: (
        <span className="text-[14px]">
          Basta acessar a sessão{" "}
          <span className="font-['Satoshi:Bold',_sans-serif] not-italic">Criar Logo{" "}</span>
          e preencher o campo
          <span className="font-['Satoshi:Bold',_sans-serif] not-italic"> Nome da sua Empresa.{" "}</span>
          A logo será gerada e você poderá baixa-lá clicando em
          <span className="font-['Satoshi:Bold',_sans-serif] not-italic"> Baixar meu Logo.</span>
        </span>
      )
    },
    {
      question: "O logo que eu gerar aqui tem prazo de validade?",
      answer: (
        <span>
          As logos geradas na sessão{" "}
          <span className="font-['Satoshi:Bold',_sans-serif] not-italic">Criar Logo</span>
          <span> tem caráter provisório, até que o cliente envie a logo oficial da sua empresa. Lembre-se que toda logo recebida pelo cliente, precisa passar pela </span>
          <span className="font-['Satoshi:Bold',_sans-serif] not-italic">Padronização de Logo{" "}</span>
          <span>para entrar no sistema.</span>
        </span>
      )
    },
    {
      question: "Por que o gerador de logo cria dois tamanhos diferentes?",
      answer: (
        <span>
          O sistema de Cadastro de Empresas, precisa da logo do cliente em dois tamanhos diferentes:{" "}
          <span className="font-['Satoshi:Bold',_sans-serif] not-italic">100x50</span>
          <span> e </span>
          <span className="font-['Satoshi:Bold',_sans-serif] not-italic">400x400</span>
          <span>, por isso o sistema gera a logo em dois tamanhos diferentes. Para adequar a logo do cliente para esses tamanhos, basta usar a sessão </span>
          <span className="font-['Satoshi:Bold',_sans-serif] not-italic">Padronizar Logo.</span>
        </span>
      )
    },
    {
      question: "Como eu cadastro o logo gerado na minha conta?",
      answer: (
        <p className="leading-[1.5]">
          <span className="text-[16px]">Basta acessar o </span>
          <a 
            href="https://sa2.fretebras.com.br/index.php#"
            className="text-decoration-line:underline text-decoration-skip-ink:none text-decoration-style:solid text-underline-position:from-font font-['Satoshi:Medium',_sans-serif] not-italic text-[14px] font-bold"
          >
            Admin
          </a>
          <span className="text-[14px]"> e clicar na aba Logo, lá você poderá carregar a logo do cliente nos tamanhos 100x50 e 400x400.</span>
        </p>
      )
    },
    {
      question: "Tive problemas na criação da minha logo e agora?",
      answer: (
        <span className="text-[14px]">
          Entre em contato com o time de design da Agência. Teremos o maior prazer em ajudar.
        </span>
      )
    }
  ];

  return (
    <>
      {/* Header Section - Using same style as home page */}
      <div className="relative">
        <div className="flex flex-col gap-3 items-center justify-start p-0 relative">
          <IconButton />
          <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center text-nowrap">
            <p className="adjustLetterSpacing block leading-[1.1] whitespace-pre font-['Satoshi:Bold',_sans-serif] text-[40px] tracking-[-1.6px] text-[rgba(17,17,17,1)] font-bold">
              Preciso de Ajuda
            </p>
          </div>
        </div>
      </div>

      {/* Description */}
      <div className="relative">
        <div className="flex flex-col gap-4 items-center justify-start p-0 relative">
          <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center text-nowrap">
            <p className="block leading-[1.5] whitespace-pre font-['Satoshi:Medium',_sans-serif] text-[16px]">
              Criamos esse FAQ para tirar suas principais dúvidas.
            </p>
          </div>
        </div>
      </div>

      <Divider />

      {/* FAQ Section */}
      <div className="w-full">
        <div className="flex flex-col gap-6 items-center">
          <div className="flex flex-col justify-center leading-[0] not-italic relative text-[#111111] text-center text-nowrap">
            <h3 className="block leading-[1.3] font-['Satoshi:Bold',_sans-serif] text-[24px] tracking-[-0.96px]">
              Perguntas frequentes
            </h3>
          </div>
          
          <div className="relative w-full">
            <div className="flex flex-col items-center justify-start p-0 relative w-full">
              {faqItems.map((item, index) => (
                <AccordionItem
                  key={index}
                  question={item.question}
                  answer={item.answer}
                  isOpen={openItems.includes(index)}
                  onToggle={() => toggleItem(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}