import svgPaths from "./svg-u6fr1fhhiq";

export default function Vector() {
  return (
    <div className="relative size-full" data-name="Vector">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 40 40"
      >
        <path
          d={svgPaths.p3615e380}
          fill="var(--fill-0, #111111)"
          id="Vector"
        />
      </svg>
    </div>
  );
}