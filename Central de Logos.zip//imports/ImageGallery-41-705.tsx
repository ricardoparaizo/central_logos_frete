import svgPaths from "./svg-7u1rrwg8vo";

export default function ImageGallery() {
  return (
    <div className="relative size-full" data-name="Image gallery">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 48 48"
      >
        <g id="Image gallery">
          <g id="Vector">
            <path
              clipRule="evenodd"
              d={svgPaths.ped2b2f0}
              fill="var(--fill-0, #111111)"
              fillRule="evenodd"
            />
            <path d={svgPaths.p1abb1700} fill="var(--fill-0, #111111)" />
          </g>
        </g>
      </svg>
    </div>
  );
}