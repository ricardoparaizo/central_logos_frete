import svgPaths from "./svg-e0k593zeaf";

export default function TruckCargo() {
  return (
    <div className="relative size-full" data-name="Truck (Cargo)">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 48 48"
      >
        <g id="Truck (Cargo)">
          <g id="Vector">
            <path d={svgPaths.p10802f00} fill="var(--fill-0, #111111)" />
            <path d={svgPaths.p18a06480} fill="var(--fill-0, #111111)" />
            <path d={svgPaths.p2416b300} fill="var(--fill-0, #111111)" />
          </g>
        </g>
      </svg>
    </div>
  );
}