import svgPaths from "./svg-9axm1d5zon";

function Component6() {
  return (
    <div className="relative shrink-0 size-[129px]" data-name="Component 6">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 129 129"
      >
        <g id="Component 6">
          <path
            d={svgPaths.p7d51140}
            fill="var(--fill-0, #111111)"
            id="Vector"
          />
          <path
            d={svgPaths.p1cb2af00}
            fill="var(--fill-0, #111111)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p125f1000}
            fill="var(--fill-0, #111111)"
            id="Vector_3"
          />
        </g>
      </svg>
    </div>
  );
}

export default function LogoG() {
  return (
    <div className="bg-[#ffffff] relative size-full" data-name="logo-g">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center px-4 py-0 relative size-full">
          <Component6 />
          <div
            className="font-['Satoshi:Bold',_sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[#111111] text-[26px] text-center tracking-[-1.04px] uppercase"
            style={{ width: "min-content" }}
          >
            <p className="block leading-[1.255]">Nome da empresa</p>
          </div>
        </div>
      </div>
    </div>
  );
}