import svgPaths from "./svg-sdfc9naus6";
import clsx from "clsx";
type MenuTextProps = {
  text: string;
  additionalClassNames?: string[];
};

function MenuText({ text, additionalClassNames = [], onClick, href }: MenuTextProps & { onClick?: () => void; href?: string }) {
  if (href) {
    return (
      <a
        href={href}
        target="_blank"
        rel="noopener noreferrer"
        className={clsx("relative cursor-pointer hover:text-[#0769da] transition-colors", additionalClassNames)}
      >
        <p className="adjustLetterSpacing block leading-[1.3] text-nowrap whitespace-pre text-[18px] text-[rgba(17,17,17,1)] font-medium">
          {text}
        </p>
      </a>
    );
  }

  return (
    <div 
      className={clsx("relative cursor-pointer hover:text-[#0769da] transition-colors", additionalClassNames)}
      onClick={onClick}
    >
      <p className="adjustLetterSpacing block leading-[1.3] text-nowrap whitespace-pre text-[18px] text-[rgba(17,17,17,1)] font-medium">
        {text}
      </p>
    </div>
  );
}

function Menu({ onNavigate }: { onNavigate?: (page: "home" | "help") => void }) {
  return (
    <div
      className="font-medium flex flex-row items-center justify-center gap-12 leading-[0] not-italic relative shrink-0 text-[#111111] text-[24px] text-left text-nowrap tracking-[-0.96px]"
      data-name="Menu"
    >
      <MenuText text="Início" onClick={() => onNavigate?.("home")} />
      <MenuText text="Ajuda" onClick={() => onNavigate?.("help")} />
      <MenuText text="Cadastro de Empresa" href="https://sa2.fretebras.com.br/index.php#" />
    </div>
  );
}

export default function Top({ onNavigate }: { onNavigate?: (page: "home" | "help") => void }) {
  return (
    <div className="bg-[#ffffff] relative size-full" data-name="Top">
      <div className="relative size-full">
        <div className="flex flex-row items-center justify-between px-24 py-6 relative w-full">
          <div 
            className="relative shrink-0 cursor-pointer" 
            style={{ width: '120px', height: '38px' }} 
            data-name="logo"
            onClick={() => onNavigate?.("home")}
          >
            <svg
              className="block"
              width="120"
              height="38"
              fill="none"
              preserveAspectRatio="none"
              viewBox="0 0 150 48"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g id="logo">
                <path d={svgPaths.p37c5df00} fill="#00AEEF" />
                <path d={svgPaths.p3e9d6800} fill="#00AEEF" />
                <path d={svgPaths.p21669f00} fill="#00AEEF" />
                <path d={svgPaths.pea1f300} fill="#00AEEF" />
                <path d={svgPaths.p7776000} fill="#00AEEF" />
                <path d={svgPaths.p16e87c80} fill="#111111" />
                <path d={svgPaths.pae73960} fill="#111111" />
                <path d={svgPaths.p24356380} fill="#111111" />
                <path d={svgPaths.p3e298580} fill="#111111" />
                <path d={svgPaths.p1be3c880} fill="#111111" />
                <path d={svgPaths.p2f535800} fill="#111111" />
                <path d={svgPaths.p1e7d3280} fill="#111111" />
                <path d={svgPaths.p7bd1400} fill="#111111" />
                <path d={svgPaths.p467e3a0} fill="#111111" />
                <path d={svgPaths.p16216000} fill="#111111" />
                <path d={svgPaths.p1ef4a7c0} fill="#111111" />
                <path d={svgPaths.p7217380} fill="#111111" />
                <path d={svgPaths.p140d0280} fill="#111111" />
                <path d={svgPaths.p2a8b7580} fill="#111111" />
                <path d={svgPaths.p724e000} fill="#111111" />
                <path d={svgPaths.p276d3900} fill="#111111" />
              </g>
            </svg>
          </div>
          <Menu onNavigate={onNavigate} />
        </div>
      </div>
    </div>
  );
}