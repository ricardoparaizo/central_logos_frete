import svgPaths from "./svg-hvsovfted4";
import clsx from "clsx";
type MenuTextProps = {
  text: string;
  additionalClassNames?: string[];
};

function MenuText({ text, additionalClassNames = [] }: MenuTextProps) {
  return (
    <div
      className={clsx("[grid-area:1_/_1] mt-0 relative", additionalClassNames)}
    >
      <p className="adjustLetterSpacing block leading-[1.3] text-nowrap whitespace-pre">
        {text}
      </p>
    </div>
  );
}

function Menu() {
  return (
    <div
      className="font-['Satoshi:Bold',_sans-serif] grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] not-italic place-items-start relative shrink-0 text-[#111111] text-[24px] text-left text-nowrap tracking-[-0.96px]"
      data-name="Menu"
    >
      <MenuText text="Início" additionalClassNames={["ml-0"]} />
      <MenuText text="Ajuda" additionalClassNames={["ml-[152px]"]} />
      <MenuText
        text="Cadastro de Empresa"
        additionalClassNames={["ml-[309px]"]}
      />
    </div>
  );
}

export default function Top() {
  return (
    <div className="bg-[#dfe1e6] relative size-full" data-name="Top">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-row gap-[150px] items-start justify-start px-24 py-10 relative size-full">
          <div className="h-12 relative shrink-0 w-[150px]" data-name="logo">
            <svg
              className="block size-full"
              fill="none"
              preserveAspectRatio="none"
              viewBox="0 0 150 48"
            >
              <g id="logo">
                <path d={svgPaths.p37c5df00} fill="#00AEEF" />
                <path d={svgPaths.p3e9d6800} fill="#00AEEF" />
                <path d={svgPaths.p21669f00} fill="#00AEEF" />
                <path d={svgPaths.pea1f300} fill="#00AEEF" />
                <path d={svgPaths.p7776000} fill="#00AEEF" />
                <path d={svgPaths.p16e87c80} fill="var(--fill-0, black)" />
                <path d={svgPaths.pae73960} fill="var(--fill-0, black)" />
                <path d={svgPaths.p24356380} fill="var(--fill-0, black)" />
                <path d={svgPaths.p3e298580} fill="var(--fill-0, black)" />
                <path d={svgPaths.p1be3c880} fill="var(--fill-0, black)" />
                <path d={svgPaths.p2f535800} fill="var(--fill-0, black)" />
                <path d={svgPaths.p1e7d3280} fill="var(--fill-0, black)" />
                <path d={svgPaths.p7bd1400} fill="var(--fill-0, black)" />
                <path d={svgPaths.p467e3a0} fill="var(--fill-0, black)" />
                <path d={svgPaths.p16216000} fill="var(--fill-0, black)" />
                <path d={svgPaths.p1ef4a7c0} fill="var(--fill-0, black)" />
                <path d={svgPaths.p7217380} fill="var(--fill-0, black)" />
                <path d={svgPaths.p140d0280} fill="var(--fill-0, black)" />
                <path d={svgPaths.p2a8b7580} fill="var(--fill-0, black)" />
                <path d={svgPaths.p724e000} fill="var(--fill-0, black)" />
                <path d={svgPaths.p276d3900} fill="var(--fill-0, black)" />
              </g>
            </svg>
          </div>
          <Menu />
        </div>
      </div>
    </div>
  );
}