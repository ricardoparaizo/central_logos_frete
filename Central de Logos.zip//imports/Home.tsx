import svgPaths from "./svg-nlbji3npuv";
import clsx from "clsx";
type BackgroundImage72Props = {
  additionalClassNames?: string[];
};

function BackgroundImage72({
  children,
  additionalClassNames = [],
}: React.PropsWithChildren<BackgroundImage72Props>) {
  return (
    <div
      className={clsx(
        "flex flex-col justify-center leading-[0] not-italic relative shrink-0 text-[#111111] text-center text-nowrap",
        additionalClassNames,
      )}
    >
      {children}
    </div>
  );
}

function FaqBackgroundImage({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-[660px]">
      <div className="box-border content-stretch flex flex-col gap-4 items-center justify-center overflow-clip p-0 relative w-[660px]">
        {children}
      </div>
    </div>
  );
}
type BackgroundImage42Props = {
  additionalClassNames?: string[];
};

function BackgroundImage42({
  children,
  additionalClassNames = [],
}: React.PropsWithChildren<BackgroundImage42Props>) {
  return (
    <div
      className={clsx(
        "relative rounded-2xl shrink-0 w-full",
        additionalClassNames,
      )}
    >
      <div className="flex flex-row items-center relative size-full">
        {children}
      </div>
    </div>
  );
}

function BackgroundImage27({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 size-5">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        {children}
      </svg>
    </div>
  );
}
type AccordionBackgroundImageProps = {
  text: string;
};

function AccordionBackgroundImage({
  children,
  text,
}: React.PropsWithChildren<AccordionBackgroundImageProps>) {
  return (
    <div className="bg-[#ffffff] relative shrink-0 w-full">
      <div className="absolute border-[#dfe1e6] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-col justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-center px-0 py-6 relative w-full">
          <div className="relative shrink-0 w-full">
            <div className="box-border content-stretch flex flex-row gap-6 items-center justify-start p-0 relative w-full">
              <div className="basis-0 font-['Satoshi:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#111111] text-[16px] text-left">
                <p className="block leading-[1.5]">{text}</p>
              </div>
              <div className="flex flex-row items-center self-stretch">
                <IconBackgroundImage />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function IconBackgroundImage() {
  return (
    <div className="h-full relative shrink-0">
      <div className="flex flex-row justify-end relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-full items-start justify-end px-0 py-0.5 relative">
          <AddBackgroundImage />
        </div>
      </div>
    </div>
  );
}

function AddBackgroundImage() {
  return (
    <BackgroundImage27>
      <g id="Add">
        <path
          d="M10 2.5V17.5M2.5 10H17.5"
          id="Vector"
          stroke="var(--stroke-0, #636B7E)"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="1.25"
        />
      </g>
    </BackgroundImage27>
  );
}

function Header() {
  return (
    <BackgroundImage42 additionalClassNames={["bg-[#ffffff]"]}>
      <div className="box-border content-stretch flex flex-row items-center justify-between px-12 py-4 relative w-full">
        <div className="h-8 relative shrink-0 w-[100px]" data-name="Vector">
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 100 32"
          >
            <g id="Vector">
              <path d={svgPaths.p3e956a00} fill="#00AEEF" />
              <path d={svgPaths.p14536b80} fill="#00AEEF" />
              <path d={svgPaths.p1f047680} fill="#00AEEF" />
              <path d={svgPaths.p1f00fe00} fill="#00AEEF" />
              <path d={svgPaths.p208b8500} fill="#00AEEF" />
              <path d={svgPaths.p283ed180} fill="var(--fill-0, black)" />
              <path d={svgPaths.p3f1f4d00} fill="var(--fill-0, black)" />
              <path d={svgPaths.p150c3080} fill="var(--fill-0, black)" />
              <path d={svgPaths.p3a6b500} fill="var(--fill-0, black)" />
              <path d={svgPaths.p89c9a00} fill="var(--fill-0, black)" />
              <path d={svgPaths.pad1d500} fill="var(--fill-0, black)" />
              <path d={svgPaths.p19363980} fill="var(--fill-0, black)" />
              <path d={svgPaths.p6218900} fill="var(--fill-0, black)" />
              <path d={svgPaths.p11d29600} fill="var(--fill-0, black)" />
              <path d={svgPaths.p3a3eda00} fill="var(--fill-0, black)" />
              <path d={svgPaths.p1a78df40} fill="var(--fill-0, black)" />
              <path d={svgPaths.p36fa8c00} fill="var(--fill-0, black)" />
              <path d={svgPaths.paa08500} fill="var(--fill-0, black)" />
              <path d={svgPaths.p12f2ec80} fill="var(--fill-0, black)" />
              <path d={svgPaths.p31538032} fill="var(--fill-0, black)" />
              <path d={svgPaths.p298ad600} fill="var(--fill-0, black)" />
            </g>
          </svg>
        </div>
      </div>
    </BackgroundImage42>
  );
}

function Star() {
  return (
    <BackgroundImage27>
      <g id="Star">
        <path
          clipRule="evenodd"
          d={svgPaths.p1b34b400}
          fill="var(--fill-0, white)"
          fillRule="evenodd"
          id="Vector"
        />
      </g>
    </BackgroundImage27>
  );
}

function IconButton() {
  return (
    <div
      className="relative rounded-[500px] shrink-0 size-12"
      data-name="Icon button"
      style={{
        backgroundImage:
          "linear-gradient(47.3859deg, rgb(7, 105, 218) 13.831%, rgb(206, 220, 255) 88.961%)",
      }}
    >
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-center p-0 relative size-12">
        <Star />
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-3 items-center justify-start p-0 relative">
        <IconButton />
        <BackgroundImage72
          additionalClassNames={[
            "font-['Satoshi:Bold',_sans-serif]",
            "text-[40px]",
            "tracking-[-1.6px]",
          ]}
        >
          <p className="adjustLetterSpacing block leading-[1.1] whitespace-pre">
            Gerador de logos
          </p>
        </BackgroundImage72>
      </div>
    </div>
  );
}

function InputField() {
  return (
    <BackgroundImage42
      additionalClassNames={["bg-[rgba(0,43,92,0.06)]", "h-12"]}
    >
      <div className="box-border content-stretch flex flex-row gap-2 h-12 items-center justify-start px-4 py-0 relative w-full">
        <div className="basis-0 font-['Satoshi:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#636b7e] text-[14px] text-left">
          <p className="block leading-[1.5]">Nome da sua empresa</p>
        </div>
      </div>
    </BackgroundImage42>
  );
}

function TextField() {
  return (
    <div className="relative shrink-0 w-[488px]" data-name="Text field">
      <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative w-[488px]">
        <InputField />
      </div>
    </div>
  );
}

function Button() {
  return (
    <div
      className="bg-[#0769da] max-h-12 min-h-12 min-w-16 relative rounded-[500px] shrink-0"
      data-name="Button"
    >
      <div className="flex flex-row items-center justify-center max-h-inherit min-h-inherit min-w-inherit relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2 items-center justify-center max-h-inherit min-h-inherit min-w-inherit px-4 py-0 relative">
          <div className="font-['Satoshi:Medium',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[14px] text-center text-nowrap">
            <p className="block leading-[1.5] whitespace-pre">Criar logo</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-4 items-center justify-start p-0 relative">
        <BackgroundImage72
          additionalClassNames={[
            "font-['Satoshi:Medium',_sans-serif]",
            "text-[16px]",
          ]}
        >
          <p className="block leading-[1.5] whitespace-pre">
            Crie um logo provisório para começar a postar fretes agora mesmo.
          </p>
        </BackgroundImage72>
        <TextField />
        <Button />
      </div>
    </div>
  );
}

function ChevronRight() {
  return (
    <div className="relative shrink-0 size-4" data-name="Chevron (Right)">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="Chevron (Right)">
          <path
            d={svgPaths.p2de3b580}
            id="Vector"
            stroke="var(--stroke-0, #0769DA)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      </svg>
    </div>
  );
}

function LinkButton() {
  return (
    <div className="relative shrink-0" data-name="Link button">
      <div className="box-border content-stretch flex flex-row gap-1 items-center justify-start p-0 relative">
        <div className="font-['Satoshi:Medium',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#0769da] text-[14px] text-center text-nowrap">
          <p className="block leading-[1.5] whitespace-pre">
            Preciso redimensionar o meu logo
          </p>
        </div>
        <ChevronRight />
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-8 items-center justify-start p-0 relative">
        <Frame6 />
        <LinkButton />
      </div>
    </div>
  );
}

function Divider() {
  return (
    <div className="relative shrink-0 w-[660px]" data-name="Divider">
      <div className="box-border content-stretch flex flex-col items-start justify-start p-0 relative w-[660px]">
        <div
          className="bg-[#dfe1e6] h-px shrink-0 w-full"
          data-name="Divider"
        />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="relative shrink-0 w-[660px]" data-name="container">
      <div className="box-border content-stretch flex flex-col items-center justify-start p-0 relative w-[660px]">
        <AccordionBackgroundImage text="Como faço para criar o meu logo?" />
        <AccordionBackgroundImage text="Por que preciso de um logo para postar fretes?" />
        <AccordionBackgroundImage text="O logo que eu gerar aqui tem prazo de validade?" />
        <AccordionBackgroundImage text="Posso usar o logo gerado aqui fora da Fretebras?" />
        <AccordionBackgroundImage text="Por que o gerador de logo cria três tamanhos diferentes?" />
        <AccordionBackgroundImage text="Como eu cadastro o logo gerado na minha conta?" />
      </div>
    </div>
  );
}

function Faq() {
  return (
    <FaqBackgroundImage>
      <div
        className="font-['Satoshi:Bold',_sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[#111111] text-[18px] text-left"
        style={{ width: "min-content" }}
      >
        <p className="block leading-[1.5]">Perguntas frequentes</p>
      </div>
      <Container />
    </FaqBackgroundImage>
  );
}

function Faq1() {
  return (
    <FaqBackgroundImage>
      <Faq />
    </FaqBackgroundImage>
  );
}

function Frame1() {
  return (
    <div className="relative shrink-0 w-[660px]">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-10 items-center justify-center px-0 py-20 relative w-[660px]">
          <Frame8 />
          <Frame2 />
          <Divider />
          <Faq1 />
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  return (
    <div className="bg-[#ffffff] relative size-full" data-name="home">
      <div className="box-border content-stretch flex flex-col items-center justify-start p-0 relative size-full">
        <Header />
        <Frame1 />
      </div>
    </div>
  );
}