import svgPaths from "./svg-2q8hyuf68j";
import clsx from "clsx";
type BackgroundImage72Props = {
  additionalClassNames?: string[];
};

function BackgroundImage72({
  children,
  additionalClassNames = [],
}: React.PropsWithChildren<BackgroundImage72Props>) {
  return (
    <div
      className={clsx(
        "flex flex-col justify-center leading-[0] not-italic relative shrink-0 text-[#111111] text-center text-nowrap",
        additionalClassNames,
      )}
    >
      {children}
    </div>
  );
}
type BackgroundImage55Props = {
  additionalClassNames?: string[];
};

function BackgroundImage55({
  children,
  additionalClassNames = [],
}: React.PropsWithChildren<BackgroundImage55Props>) {
  return (
    <div
      className={clsx(
        "relative rounded-2xl shrink-0 w-full",
        additionalClassNames,
      )}
    >
      <div className="flex flex-row items-center relative size-full">
        {children}
      </div>
    </div>
  );
}

function BackgroundImage40({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 size-5">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        {children}
      </svg>
    </div>
  );
}
type AccordionBackgroundImageProps = {
  text: string;
};

function AccordionBackgroundImage({
  children,
  text,
}: React.PropsWithChildren<AccordionBackgroundImageProps>) {
  return (
    <div className="bg-[#ffffff] relative shrink-0 w-full">
      <div className="absolute border-[#dfe1e6] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-col justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-center px-0 py-6 relative w-full">
          <div className="relative shrink-0 w-full">
            <div className="box-border content-stretch flex flex-row gap-6 items-center justify-start p-0 relative w-full">
              <div className="basis-0 font-['Satoshi:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#111111] text-[16px] text-left">
                <p className="block leading-[1.5]">{text}</p>
              </div>
              <div className="flex flex-row items-center self-stretch">
                <IconBackgroundImage />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
type ButtonBackgroundImageProps = {
  additionalClassNames?: string[];
};

function ButtonBackgroundImage({
  children,
  additionalClassNames = [],
}: React.PropsWithChildren<ButtonBackgroundImageProps>) {
  return (
    <div
      className={clsx(
        "max-h-12 min-h-12 min-w-16 relative rounded-[500px] shrink-0",
        additionalClassNames,
      )}
    >
      <div className="flex flex-row items-center justify-center max-h-inherit min-h-inherit min-w-inherit relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2 items-center justify-center max-h-inherit min-h-inherit min-w-inherit px-4 py-0 relative">
          {children}
        </div>
      </div>
    </div>
  );
}

function IconBackgroundImage() {
  return (
    <div className="h-full relative shrink-0">
      <div className="flex flex-row justify-end relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-full items-start justify-end px-0 py-0.5 relative">
          <AddBackgroundImage />
        </div>
      </div>
    </div>
  );
}

function AddBackgroundImage() {
  return (
    <BackgroundImage40>
      <g id="Add">
        <path
          d="M10 2.5V17.5M2.5 10H17.5"
          id="Vector"
          stroke="var(--stroke-0, #636B7E)"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="1.25"
        />
      </g>
    </BackgroundImage40>
  );
}

function Header() {
  return (
    <BackgroundImage55 additionalClassNames={["bg-[#ffffff]"]}>
      <div className="box-border content-stretch flex flex-row items-center justify-between px-12 py-4 relative w-full">
        <div className="h-8 relative shrink-0 w-[100px]" data-name="Vector">
          <svg
            className="block size-full"
            fill="none"
            preserveAspectRatio="none"
            viewBox="0 0 100 32"
          >
            <g id="Vector">
              <path d={svgPaths.p3e956a00} fill="#00AEEF" />
              <path d={svgPaths.p14536b80} fill="#00AEEF" />
              <path d={svgPaths.p1f047680} fill="#00AEEF" />
              <path d={svgPaths.p1f00fe00} fill="#00AEEF" />
              <path d={svgPaths.p208b8500} fill="#00AEEF" />
              <path d={svgPaths.p283ed180} fill="var(--fill-0, black)" />
              <path d={svgPaths.p3f1f4d00} fill="var(--fill-0, black)" />
              <path d={svgPaths.p150c3080} fill="var(--fill-0, black)" />
              <path d={svgPaths.p3a6b500} fill="var(--fill-0, black)" />
              <path d={svgPaths.p89c9a00} fill="var(--fill-0, black)" />
              <path d={svgPaths.pad1d500} fill="var(--fill-0, black)" />
              <path d={svgPaths.p19363980} fill="var(--fill-0, black)" />
              <path d={svgPaths.p6218900} fill="var(--fill-0, black)" />
              <path d={svgPaths.p11d29600} fill="var(--fill-0, black)" />
              <path d={svgPaths.p3a3eda00} fill="var(--fill-0, black)" />
              <path d={svgPaths.p1a78df40} fill="var(--fill-0, black)" />
              <path d={svgPaths.p36fa8c00} fill="var(--fill-0, black)" />
              <path d={svgPaths.paa08500} fill="var(--fill-0, black)" />
              <path d={svgPaths.p12f2ec80} fill="var(--fill-0, black)" />
              <path d={svgPaths.p31538032} fill="var(--fill-0, black)" />
              <path d={svgPaths.p298ad600} fill="var(--fill-0, black)" />
            </g>
          </svg>
        </div>
      </div>
    </BackgroundImage55>
  );
}

function Star() {
  return (
    <BackgroundImage40>
      <g id="Star">
        <path
          clipRule="evenodd"
          d={svgPaths.p1b34b400}
          fill="var(--fill-0, white)"
          fillRule="evenodd"
          id="Vector"
        />
      </g>
    </BackgroundImage40>
  );
}

function IconButton() {
  return (
    <div
      className="relative rounded-[500px] shrink-0 size-12"
      data-name="Icon button"
      style={{
        backgroundImage:
          "linear-gradient(47.3859deg, rgb(7, 105, 218) 13.831%, rgb(206, 220, 255) 88.961%)",
      }}
    >
      <div className="box-border content-stretch flex flex-row gap-2 items-center justify-center p-0 relative size-12">
        <Star />
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-3 items-center justify-start p-0 relative">
        <IconButton />
        <BackgroundImage72
          additionalClassNames={[
            "font-['Satoshi:Bold',_sans-serif]",
            "text-[40px]",
            "tracking-[-1.6px]",
          ]}
        >
          <p className="adjustLetterSpacing block leading-[1.1] whitespace-pre">
            Gerador de logos
          </p>
        </BackgroundImage72>
      </div>
    </div>
  );
}

function LabelValue() {
  return (
    <div
      className="basis-0 grow h-full min-h-px min-w-px relative shrink-0"
      data-name="Label+Value"
    >
      <div className="box-border content-stretch flex flex-col font-['Satoshi:Medium',_sans-serif] gap-0.5 items-start justify-center leading-[0] not-italic p-0 relative size-full text-left">
        <div className="relative shrink-0 text-[#636b7e] text-[10px] w-full">
          <p className="block leading-[1.2]">Nome da sua empresa</p>
        </div>
        <div className="relative shrink-0 text-[#111111] text-[14px] w-full">
          <p className="block leading-[1.5]">Vittorio Transportes</p>
        </div>
      </div>
    </div>
  );
}

function InputField() {
  return (
    <BackgroundImage55
      additionalClassNames={["bg-[rgba(0,43,92,0.06)]", "h-12"]}
    >
      <div className="box-border content-stretch flex flex-row gap-2 h-12 items-center justify-start px-4 py-0 relative w-full">
        <LabelValue />
      </div>
    </BackgroundImage55>
  );
}

function TextField() {
  return (
    <div className="relative shrink-0 w-[488px]" data-name="Text field">
      <div className="box-border content-stretch flex flex-col gap-1 items-start justify-start p-0 relative w-[488px]">
        <InputField />
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-4 items-start justify-start p-0 relative">
        <BackgroundImage72
          additionalClassNames={[
            "font-['Satoshi:Medium',_sans-serif]",
            "text-[16px]",
          ]}
        >
          <p className="block leading-[1.5] whitespace-pre">
            Crie um logo provisório para começar a postar fretes agora mesmo.
          </p>
        </BackgroundImage72>
        <TextField />
      </div>
    </div>
  );
}

function Component6() {
  return (
    <div className="relative shrink-0 size-[129px]" data-name="Component 6">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 129 129"
      >
        <g id="Component 6">
          <path
            d={svgPaths.p7d51140}
            fill="var(--fill-0, #111111)"
            id="Vector"
          />
          <path
            d={svgPaths.p1cb2af00}
            fill="var(--fill-0, #111111)"
            id="Vector_2"
          />
          <path
            d={svgPaths.p125f1000}
            fill="var(--fill-0, #111111)"
            id="Vector_3"
          />
        </g>
      </svg>
    </div>
  );
}

function LogoG() {
  return (
    <div
      className="bg-[#ffffff] relative shrink-0 size-[400px]"
      data-name="logo-g"
    >
      <div className="absolute border border-[#babec9] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2.5 items-center justify-center px-4 py-0 relative size-[400px]">
          <Component6 />
          <div
            className="font-['Satoshi:Bold',_sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[#111111] text-[26px] text-center tracking-[-1.04px] uppercase"
            style={{ width: "min-content" }}
          >
            <p className="block leading-[1.255]">Vittorio transportes</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Button() {
  return (
    <ButtonBackgroundImage additionalClassNames={["bg-[rgba(0,43,92,0.06)]"]}>
      <div className="font-['Satoshi:Medium',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#111111] text-[14px] text-center text-nowrap">
        <p className="block leading-[1.5] whitespace-pre">Criar novo logo</p>
      </div>
    </ButtonBackgroundImage>
  );
}

function Button1() {
  return (
    <ButtonBackgroundImage additionalClassNames={["bg-[#0769da]"]}>
      <div className="font-['Satoshi:Medium',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#ffffff] text-[14px] text-center text-nowrap">
        <p className="block leading-[1.5] whitespace-pre">Baixar meu logo</p>
      </div>
    </ButtonBackgroundImage>
  );
}

function Frame3() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-row gap-4 items-start justify-start p-0 relative">
        <Button />
        <Button1 />
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-4 items-center justify-start p-0 relative">
        <LogoG />
        <BackgroundImage72
          additionalClassNames={[
            "font-['Satoshi:Bold',_sans-serif]",
            "text-[0px]",
          ]}
        >
          <p className="leading-[1.5] text-[16px] whitespace-pre">
            <span>{`Pronto! `}</span>
            <span className="font-['Satoshi:Medium',_sans-serif] not-italic">
              Agora é só baixar o seu logo.
            </span>
          </p>
        </BackgroundImage72>
        <Frame3 />
      </div>
    </div>
  );
}

function ChevronRight() {
  return (
    <div className="relative shrink-0 size-4" data-name="Chevron (Right)">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 16 16"
      >
        <g id="Chevron (Right)">
          <path
            d={svgPaths.p2de3b580}
            id="Vector"
            stroke="var(--stroke-0, #0769DA)"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      </svg>
    </div>
  );
}

function LinkButton() {
  return (
    <div className="relative shrink-0" data-name="Link button">
      <div className="box-border content-stretch flex flex-row gap-1 items-center justify-start p-0 relative">
        <div className="font-['Satoshi:Medium',_sans-serif] leading-[0] not-italic relative shrink-0 text-[#0769da] text-[14px] text-center text-nowrap">
          <p className="block leading-[1.5] whitespace-pre">
            Preciso adequar o tamanho do meu logo
          </p>
        </div>
        <ChevronRight />
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-8 items-center justify-start p-0 relative">
        <Frame5 />
        <Frame4 />
        <LinkButton />
      </div>
    </div>
  );
}

function Divider() {
  return (
    <div className="relative shrink-0 w-[660px]" data-name="Divider">
      <div className="box-border content-stretch flex flex-col items-start justify-start p-0 relative w-[660px]">
        <div
          className="bg-[#dfe1e6] h-px shrink-0 w-full"
          data-name="Divider"
        />
      </div>
    </div>
  );
}

function Container() {
  return (
    <div className="relative shrink-0 w-[660px]" data-name="container">
      <div className="box-border content-stretch flex flex-col items-center justify-start p-0 relative w-[660px]">
        <AccordionBackgroundImage text="Como faço para criar o meu logo?" />
        <AccordionBackgroundImage text="Por que preciso de um logo para postar fretes?" />
        <AccordionBackgroundImage text="O logo que eu gerar aqui tem prazo de validade?" />
        <AccordionBackgroundImage text="Posso usar o logo gerado aqui fora da Fretebras?" />
        <AccordionBackgroundImage text="Como eu cadastro o logo gerado na minha conta?" />
      </div>
    </div>
  );
}

function Faq() {
  return (
    <div className="relative shrink-0 w-[660px]" data-name="FAQ">
      <div className="box-border content-stretch flex flex-col gap-4 items-center justify-center overflow-clip p-0 relative w-[660px]">
        <div
          className="font-['Satoshi:Bold',_sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[#111111] text-[18px] text-left"
          style={{ width: "min-content" }}
        >
          <p className="block leading-[1.5]">Perguntas frequentes</p>
        </div>
        <Container />
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="relative shrink-0 w-[660px]">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-10 items-center justify-center px-0 py-20 relative w-[660px]">
          <Frame8 />
          <Frame2 />
          <Divider />
          <Faq />
        </div>
      </div>
    </div>
  );
}

export default function HomeLogopreview() {
  return (
    <div
      className="bg-[#ffffff] relative size-full"
      data-name="home-logopreview"
    >
      <div className="box-border content-stretch flex flex-col items-center justify-start p-0 relative size-full">
        <Header />
        <Frame1 />
      </div>
    </div>
  );
}