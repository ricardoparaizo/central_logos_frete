type AccordionProps = {
  text: string;
};

function Accordion({
  children,
  text,
}: React.PropsWithChildren<AccordionProps>) {
  return (
    <div className="bg-[#ffffff] relative shrink-0 w-full">
      <div className="absolute border-[#dfe1e6] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-col justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-center px-0 py-6 relative w-full">
          <div className="relative shrink-0 w-full">
            <div className="box-border content-stretch flex flex-row gap-6 items-center justify-start p-0 relative w-full">
              <div className="basis-0 font-['Satoshi:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#111111] text-[16px] text-left">
                <p className="block leading-[1.5]">{text}</p>
              </div>
              <div className="flex flex-row items-center self-stretch">
                <Icon />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="h-full relative shrink-0">
      <div className="flex flex-row justify-end relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-full items-start justify-end px-0 py-0.5 relative">
          <Add />
        </div>
      </div>
    </div>
  );
}

function Add() {
  return (
    <div className="relative shrink-0 size-5">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="Add">
          <path
            d="M10 2.5V17.5M2.5 10H17.5"
            id="Vector"
            stroke="var(--stroke-0, #636B7E)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.25"
          />
        </g>
      </svg>
    </div>
  );
}

function Container() {
  return (
    <div className="relative shrink-0 w-[660px]" data-name="container">
      <div className="box-border content-stretch flex flex-col items-center justify-start p-0 relative w-[660px]">
        <Accordion text="Como faço para criar o meu logo?" />
        <Accordion text="Por que preciso de um logo para postar fretes?" />
        <Accordion text="O logo que eu gerar aqui tem prazo de validade?" />
        <Accordion text="Posso usar o logo gerado aqui fora da Fretebras?" />
        <Accordion text="Como eu cadastro o logo gerado na minha conta?" />
      </div>
    </div>
  );
}

export default function Faq() {
  return (
    <div className="relative size-full" data-name="FAQ">
      <div className="box-border content-stretch flex flex-col gap-4 items-center justify-center p-0 relative size-full">
        <div
          className="font-['Satoshi:Bold',_sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[#111111] text-[18px] text-left"
          style={{ width: "min-content" }}
        >
          <p className="block leading-[1.5]">Perguntas frequentes</p>
        </div>
        <Container />
      </div>
    </div>
  );
}