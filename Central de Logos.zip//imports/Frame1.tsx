import svgPaths from "./svg-ax4nfu75ds";

function Faq2({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-[660px]">
      <div className="box-border content-stretch flex flex-col gap-4 items-center justify-center overflow-clip p-0 relative w-[660px]">
        {children}
      </div>
    </div>
  );
}

function Accordion4({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="bg-[#ffffff] relative shrink-0 w-full">
      <div className="absolute border-[#dfe1e6] border-[0px_0px_1px] border-solid inset-0 pointer-events-none" />
      <div className="flex flex-col justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-2 items-start justify-center px-0 py-6 relative w-full">
          {children}
        </div>
      </div>
    </div>
  );
}

function Wrapper({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 items-start justify-start pl-0 pr-5 py-0 relative w-full">
          {children}
        </div>
      </div>
    </div>
  );
}

function Answer4({ children }: React.PropsWithChildren<{}>) {
  return (
    <Wrapper>
      <div className="basis-0 font-['Satoshi:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#636b7e] text-[0px] text-left">
        <p className="leading-[1.5] text-[16px]">{children}</p>
      </div>
    </Wrapper>
  );
}
type QuestionheadlineTextProps = {
  text: string;
};

function QuestionheadlineText({ text }: QuestionheadlineTextProps) {
  return (
    <div className="relative shrink-0 w-full">
      <div className="box-border content-stretch flex flex-row gap-6 items-center justify-start p-0 relative w-full">
        <div className="basis-0 font-['Satoshi:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#111111] text-[16px] text-left">
          <p className="block leading-[1.5]">{text}</p>
        </div>
        <div className="flex flex-row items-center self-stretch">
          <Icon />
        </div>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="h-full relative shrink-0">
      <div className="flex flex-row justify-end relative size-full">
        <div className="box-border content-stretch flex flex-row gap-2.5 h-full items-start justify-end px-0 py-0.5 relative">
          <Add />
        </div>
      </div>
    </div>
  );
}

function Add() {
  return (
    <div className="relative shrink-0 size-5">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 20 20"
      >
        <g id="Add">
          <path
            d="M10 2.5V17.5M2.5 10H17.5"
            id="Vector"
            stroke="var(--stroke-0, #636B7E)"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth="1.25"
          />
        </g>
      </svg>
    </div>
  );
}

function Question() {
  return (
    <div className="relative shrink-0 size-12" data-name="Question">
      <svg
        className="block size-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 48 48"
      >
        <g id="Question">
          <g id="Vector">
            <path d={svgPaths.p9ed8700} fill="var(--fill-0, #111111)" />
            <path d={svgPaths.p9ed8700} fill="url(#paint0_linear_41_386)" />
          </g>
        </g>
        <defs>
          <linearGradient
            gradientUnits="userSpaceOnUse"
            id="paint0_linear_41_386"
            x1="9"
            x2="40.25"
            y1="37.8889"
            y2="9.13888"
          >
            <stop stopColor="#0769DA" />
            <stop offset="1" stopColor="#CEDCFF" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Frame8() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-3 items-center justify-start p-0 relative">
        <Question />
        <div className="flex flex-col font-['Satoshi:Bold',_sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#111111] text-[40px] text-center text-nowrap tracking-[-1.6px]">
          <p className="adjustLetterSpacing block leading-[1.1] whitespace-pre">
            Preciso de Ajuda
          </p>
        </div>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-4 items-center justify-start p-0 relative">
        <div className="flex flex-col font-['Satoshi:Medium',_sans-serif] justify-center leading-[1.5] not-italic relative shrink-0 text-[#111111] text-[16px] text-center text-nowrap whitespace-pre">
          <p className="block mb-0">{`Precisa de ajuda com o sistema Central de logos? `}</p>
          <p className="block">{`Criamos esse FAQ para tirar suas principais dúvidas. `}</p>
        </div>
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="relative shrink-0">
      <div className="box-border content-stretch flex flex-col gap-8 items-center justify-start p-0 relative">
        <Frame6 />
      </div>
    </div>
  );
}

function Divider() {
  return (
    <div className="relative shrink-0 w-[660px]" data-name="Divider">
      <div className="box-border content-stretch flex flex-col items-start justify-start p-0 relative w-[660px]">
        <div
          className="bg-[#dfe1e6] h-px shrink-0 w-full"
          data-name="Divider"
        />
      </div>
    </div>
  );
}

function Answer() {
  return (
    <Answer4>
      <span>{`Basta acessar a sessão `}</span>
      <span className="font-['Satoshi:Bold',_sans-serif] not-italic">{`Criar Logo `}</span>
      e preencher o campo
      <span className="font-['Satoshi:Bold',_sans-serif] not-italic">{` Nome da sua Empresa. `}</span>
      A logo será gerada e você poderá baixa-lá clicando em
      <span className="font-['Satoshi:Bold',_sans-serif] not-italic">{` Baixar meu Logo.`}</span>
    </Answer4>
  );
}

function Accordion() {
  return (
    <Accordion4>
      <QuestionheadlineText text="Como faço para criar o meu logo?" />
      <Answer />
    </Accordion4>
  );
}

function Answer1() {
  return (
    <Answer4>
      <span>{`As logos geradas na sessão `}</span>
      <span className="font-['Satoshi:Bold',_sans-serif] not-italic">
        Criar Logo
      </span>
      <span>{` tem caráter provisório, até que o cliente envie a logo oficial da sua empresa. Lembre-se que toda logo recebida pelo cliente, precisa passar pela `}</span>
      <span className="font-['Satoshi:Bold',_sans-serif] not-italic">{`Padronização de Logo `}</span>
      <span>{`para entrar no sistema. `}</span>
    </Answer4>
  );
}

function Accordion1() {
  return (
    <Accordion4>
      <QuestionheadlineText text="O logo que eu gerar aqui tem prazo de validade?" />
      <Answer1 />
    </Accordion4>
  );
}

function Answer2() {
  return (
    <Answer4>
      <span>{`O sistema de Cadastro de Empresas, precisa da logo do cliente em dois tamanhos diferentes: `}</span>
      <span className="font-['Satoshi:Bold',_sans-serif] not-italic">
        100x50
      </span>
      <span>{` e `}</span>
      <span className="font-['Satoshi:Bold',_sans-serif] not-italic">
        400x400
      </span>
      <span>{`, por isso o sistema gera a logo em dois tamanhos diferentes. Para adequar a logo do cliente para esses tamanhos, basta usar a sessão `}</span>
      <span className="font-['Satoshi:Bold',_sans-serif] not-italic">
        Padronizar Logo.
      </span>
    </Answer4>
  );
}

function Accordion2() {
  return (
    <Accordion4>
      <QuestionheadlineText text="Por que o gerador de logo cria dois tamanhos diferentes?" />
      <Answer2 />
    </Accordion4>
  );
}

function Answer3() {
  return (
    <Wrapper>
      <a
        className="basis-0 block cursor-pointer font-['Satoshi:Medium',_sans-serif] grow leading-[0] min-h-px min-w-px not-italic relative shrink-0 text-[#636b7e] text-[0px] text-left"
        href="https://sa2.fretebras.com.br/index.php#"
      >
        <p className="leading-[1.5]">
          <span className="text-[16px]">{`Basta acessar o `}</span>
          <span className="[text-decoration-line:underline] [text-decoration-skip-ink:none] [text-decoration-style:solid] [text-underline-position:from-font] font-['Satoshi:Medium',_sans-serif] not-italic text-[18px]">
            Admin
          </span>
          <span className="text-[16px]">{` e clicar na aba Logo, lá você poderá carregar a logo do cliente nos tamanhos 100x50 e 400x400.`}</span>
        </p>
      </a>
    </Wrapper>
  );
}

function Accordion3() {
  return (
    <Accordion4>
      <QuestionheadlineText text="Como eu cadastro o logo gerado na minha conta?" />
      <Answer3 />
    </Accordion4>
  );
}

function Container() {
  return (
    <div className="relative shrink-0 w-[660px]" data-name="container">
      <div className="box-border content-stretch flex flex-col items-center justify-start p-0 relative w-[660px]">
        <Accordion />
        <Accordion1 />
        <Accordion2 />
        <Accordion3 />
      </div>
    </div>
  );
}

function Faq() {
  return (
    <Faq2>
      <div
        className="font-['Satoshi:Bold',_sans-serif] leading-[0] min-w-full not-italic relative shrink-0 text-[#111111] text-[18px] text-left"
        style={{ width: "min-content" }}
      >
        <p className="block leading-[1.5]">Perguntas frequentes</p>
      </div>
      <Container />
    </Faq2>
  );
}

function Faq1() {
  return (
    <Faq2>
      <Faq />
    </Faq2>
  );
}

export default function Frame1() {
  return (
    <div className="relative size-full">
      <div className="flex flex-col items-center justify-center relative size-full">
        <div className="box-border content-stretch flex flex-col gap-10 items-center justify-center px-0 py-20 relative size-full">
          <Frame8 />
          <Frame2 />
          <Divider />
          <Faq1 />
        </div>
      </div>
    </div>
  );
}