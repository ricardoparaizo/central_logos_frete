import clsx from "clsx";
type WrapperProps = {
  additionalClassNames?: string[];
};

function Wrapper({
  children,
  additionalClassNames = [],
}: React.PropsWithChildren<WrapperProps>) {
  return (
    <div
      className={clsx(
        "absolute font-['Satoshi:Medium',_sans-serif] leading-[1.3] left-[1049px] not-italic text-[#636b7e] text-[34px] text-left tracking-[-1.36px] w-[707px]",
        additionalClassNames,
      )}
    >
      {children}
    </div>
  );
}
type PrinciplesText1Props = {
  text: string;
  additionalClassNames?: string[];
};

function PrinciplesText1({
  text,
  additionalClassNames = [],
}: PrinciplesText1Props) {
  return (
    <p className={clsx("adjustLetterSpacing block", additionalClassNames)}>
      {text}
    </p>
  );
}
type PrinciplesTextProps = {
  text: string;
  additionalClassNames?: string[];
};

function PrinciplesText({
  text,
  additionalClassNames = [],
}: PrinciplesTextProps) {
  return (
    <div
      className={clsx(
        "absolute font-['Satoshi:Medium',_sans-serif] leading-[0] left-[220px] not-italic text-[#111111] text-[64px] text-left tracking-[-2.56px]",
        additionalClassNames,
      )}
    >
      <p className="adjustLetterSpacing block leading-[1.3]">{text}</p>
    </div>
  );
}
type DividerProps = {
  additionalClassNames?: string[];
};

function Divider({ additionalClassNames = [] }: DividerProps) {
  return (
    <div
      className={clsx(
        "absolute left-1/2 translate-x-[-50%] w-[1760px]",
        additionalClassNames,
      )}
    >
      <div className="relative size-full">
        <div className="box-border content-stretch flex flex-col items-start justify-start px-0 py-4 relative w-[1760px]">
          <div
            className="bg-[#dfe1e6] h-px shrink-0 w-full"
            data-name="Divider"
          />
        </div>
      </div>
    </div>
  );
}

export default function Principles() {
  return (
    <div
      className="bg-[#ffffff] overflow-clip relative rounded-3xl size-full"
      data-name="Principles"
    >
      <div className="absolute font-['Satoshi:Bold',_sans-serif] leading-[0] left-20 not-italic opacity-70 text-[#babec9] text-[0px] text-left text-nowrap top-20 tracking-[-2.4px]">
        <p className="leading-none text-[40px] whitespace-pre">
          <span>{`Fuel® `}</span>
          <span className="adjustLetterSpacing font-['Satoshi:Regular',_sans-serif] not-italic">
            Design System
          </span>
        </p>
      </div>
      <div className="absolute font-['Satoshi:Medium',_sans-serif] leading-[0] left-20 not-italic text-[#111111] text-[172px] text-left text-nowrap top-60 tracking-[-6.88px]">
        <p className="adjustLetterSpacing block leading-[1.3] whitespace-pre">
          Design principles
        </p>
      </div>
      <div className="absolute font-['Satoshi:Medium',_sans-serif] leading-[0] left-20 not-italic text-[#636b7e] text-[34px] text-left top-[544px] tracking-[-1.36px] w-[848px]">
        <PrinciplesText1
          text="Os princípios de design atuam como padrões para a equipe do produto e nos ajudam a medir a qualidade do nosso trabalho. Eles substituem ideais subjetivas por definições claras que ajudam os membros da equipe a tomar decisões de design centradas no usuário."
          additionalClassNames={["leading-[1.3]"]}
        />
      </div>
      <Wrapper additionalClassNames={["top-[1867px]"]}>
        <PrinciplesText1
          text="Construímos produtos intuitivos, alinhados às expectativas e comportamentos das pessoas usuárias, evitando complexidades desnecessárias."
          additionalClassNames={["mb-0"]}
        />
        <p className="adjustLetterSpacing block mb-0">&nbsp;</p>
        <PrinciplesText1 text="Criamos jornadas otimizadas e voltadas à resolução direta das necessidades dos nossos clientes." />
      </Wrapper>
      <Wrapper additionalClassNames={["top-[2584px]"]}>
        <PrinciplesText1
          text="Utilizamos uma linguagem simples e direta, complementando com recursos visuais para transmitir informações de maneira envolvente e livre de desordem ou ruídos, independentemente da plataforma."
          additionalClassNames={["mb-0"]}
        />
        <p className="adjustLetterSpacing block mb-0">&nbsp;</p>
        <PrinciplesText1 text="Adaptamos o tom de voz e a estrutura da interface de acordo com o perfil do usuário e o contexto, mantendo a consistência entre os diferentes canais." />
      </Wrapper>
      <Wrapper additionalClassNames={["top-[3433px]"]}>
        <PrinciplesText1
          text="Estabelecemos uma parceria de confiança com nossos clientes, facilitando a comunicação e o entendimento entre as partes, garantindo transparência em cada etapa da jornada."
          additionalClassNames={["mb-0"]}
        />
        <p className="adjustLetterSpacing block mb-0">&nbsp;</p>
        <PrinciplesText1
          text="Nos promovemos de forma séria e profissional, com conteúdos de alta qualidade que reforcem nossa posição como líderes de mercado."
          additionalClassNames={["mb-0"]}
        />
        <p className="adjustLetterSpacing block mb-0">&nbsp;</p>
        <PrinciplesText1 text="Asseguramos que tudo seja apresentado com clareza, sem surpresas, para fortalecer o vínculo e a tranquilidade ao longo de toda a experiência." />
      </Wrapper>
      <PrinciplesText
        text="Valorizamos a simplicidade e a otimização de tempo"
        additionalClassNames={["top-[1867px]", "w-[742px]"]}
      />
      <div className="absolute font-['Satoshi:Medium',_sans-serif] leading-[0] left-20 not-italic text-[#babec9] text-[36px] text-left text-nowrap top-[1927px] tracking-[-1.44px]">
        <p className="adjustLetterSpacing block leading-[1.3] whitespace-pre">
          01
        </p>
      </div>
      <div className="absolute font-['Satoshi:Medium',_sans-serif] leading-[0] left-20 not-italic text-[#babec9] text-[36px] text-left text-nowrap top-[2644px] tracking-[-1.44px]">
        <p className="adjustLetterSpacing block leading-[1.3] whitespace-pre">
          02
        </p>
      </div>
      <div className="absolute font-['Satoshi:Medium',_sans-serif] leading-[0] left-20 not-italic text-[#babec9] text-[36px] text-left text-nowrap top-[3534px] tracking-[-1.44px]">
        <p className="adjustLetterSpacing block leading-[1.3] whitespace-pre">
          03
        </p>
      </div>
      <PrinciplesText
        text="Comunicação clara, objetiva e acessível"
        additionalClassNames={["top-[2584px]", "w-[742px]"]}
      />
      <PrinciplesText
        text="Interações e interfaces que promovem confiança e credibilidade"
        additionalClassNames={["top-[3433px]", "w-[690px]"]}
      />
      <div className="absolute bg-zinc-100 h-[738px] left-20 rounded-2xl top-[888px] w-[1760px]" />
      <Divider additionalClassNames={["top-[2455px]"]} />
      <Divider additionalClassNames={["top-[1738px]"]} />
      <Divider additionalClassNames={["top-[3304px]"]} />
      <div className="absolute font-['Satoshi:Medium',_sans-serif] leading-[0] left-[885px] not-italic text-[#babec9] text-[16px] text-left text-nowrap top-[1247px]">
        <p className="block leading-[1.3] whitespace-pre">
          illustration goes here
        </p>
      </div>
    </div>
  );
}